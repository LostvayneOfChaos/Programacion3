
package pe.edu.personal.dao;
import java.util.ArrayList;
import pe.edu.personal.Especialidad;
/**
 *
 * @author AXEL
 */
public interface EspecialidadDAO {
    int insertar(Especialidad especialidad);
    int modificar(Especialidad especialidad);
    int eliminar(int idEspecialidad);
    ArrayList<Especialidad> listarTodas();
    
    
}
