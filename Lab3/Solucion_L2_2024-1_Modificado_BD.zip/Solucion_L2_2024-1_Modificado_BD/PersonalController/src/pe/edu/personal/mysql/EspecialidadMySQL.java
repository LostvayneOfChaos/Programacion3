
package pe.edu.personal.mysql;
import pe.edu.personal.dao.EspecialidadDAO;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.ArrayList;
import pe.edu.config.DBManager;
import pe.edu.personal.Especialidad;

/**
 *
 * @author AXEL
 */
public class EspecialidadMySQL implements EspecialidadDAO{
    private Connection con=null;
    private Statement st;
    
    @Override
    public int insertar(Especialidad especialidad) {
        int resultado = 0;
        try{
            //Registrar un driver conexion
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Realizamos la conexion
            con = DriverManager.getConnection(
        DBManager.url,DBManager.user,DBManager.password);
            String sql = "INSERT INTO especialidad(nombre) "
                    + "VALUES('" + especialidad.getNombre() + "' )";
            st = con.createStatement();
            resultado = st.executeUpdate(sql);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{con.close();}catch(Exception ex){System.out.println(ex.getMessage());}
        }
        return resultado;
    }

    @Override
    public int modificar(Especialidad especialidad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int eliminar(int idEspecialidad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Especialidad> listarTodas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
