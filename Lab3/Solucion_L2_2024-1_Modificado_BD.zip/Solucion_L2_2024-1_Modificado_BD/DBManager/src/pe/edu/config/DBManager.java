
package pe.edu.config;

/**
 *
 * @author AXEL
 */
public class DBManager {
    public static String url="jdbc:mysql://"+"base-datos-prog3.crocm8ksso70.us-east-1.rds.amazonaws.com"+
            ":3306/BD_prog3";
    public static String user="admin";
    public static String password="PEPE27548147";
    
    
    
}
