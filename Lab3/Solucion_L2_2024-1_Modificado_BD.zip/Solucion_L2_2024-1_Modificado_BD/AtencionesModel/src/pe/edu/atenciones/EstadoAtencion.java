package pe.edu.atenciones;
public enum EstadoAtencion{
	PROGRAMADA, CONFIRMADA, EN_CURSO, COMPLETADA
}