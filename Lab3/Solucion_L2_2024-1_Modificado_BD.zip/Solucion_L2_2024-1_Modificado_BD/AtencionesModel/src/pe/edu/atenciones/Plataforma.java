package pe.edu.atenciones;
public enum Plataforma{
	ZOOM, WEBEX
}