package pe.edu.atenciones;
public enum TipoExamen{
	ECOGRAFIA, RESONANCIA, TOMOGRAFIA, RAYOS_X
}