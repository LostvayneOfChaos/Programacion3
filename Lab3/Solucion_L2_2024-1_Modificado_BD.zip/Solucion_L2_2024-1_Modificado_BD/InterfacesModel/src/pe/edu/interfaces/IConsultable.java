package pe.edu.interfaces;
public interface IConsultable{
	String devolverInformacion();
}