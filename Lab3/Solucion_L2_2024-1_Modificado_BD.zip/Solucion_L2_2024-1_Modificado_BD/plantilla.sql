select * from especialidad;

delete from especialidad
where nombre="MEDICINA INTERNA";

Create table especialidad(
	nombre VARCHAR(200),
    primary key(nombre)


)ENGINE=InnoDB;