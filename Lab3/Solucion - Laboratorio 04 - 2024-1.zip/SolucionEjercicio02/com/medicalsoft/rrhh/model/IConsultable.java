package com.medicalsoft.rrhh.model;
public interface IConsultable{
	String devolverInformacion();
}