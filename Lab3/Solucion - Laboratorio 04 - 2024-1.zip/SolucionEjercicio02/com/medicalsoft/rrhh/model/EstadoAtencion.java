package com.medicalsoft.rrhh.model;
public enum EstadoAtencion{
	PROGRAMADA, CONFIRMADA, EN_CURSO, COMPLETADA
}