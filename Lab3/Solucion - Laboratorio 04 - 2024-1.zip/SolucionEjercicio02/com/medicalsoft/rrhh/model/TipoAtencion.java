package com.medicalsoft.rrhh.model;
public enum TipoAtencion{
	CITA_MEDICA, EXAMEN_DIAGNOSTICO
}