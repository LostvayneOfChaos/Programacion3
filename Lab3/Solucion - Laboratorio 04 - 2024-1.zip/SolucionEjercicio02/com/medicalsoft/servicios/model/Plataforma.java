package com.medicalsoft.servicios.model;
public enum Plataforma{
	ZOOM, WEBEX
}