package com.medicalsoft.infraestructura.model;
public enum TipoExamen{
	ECOGRAFIA, RESONANCIA, TOMOGRAFIA, RAYOS_X
}