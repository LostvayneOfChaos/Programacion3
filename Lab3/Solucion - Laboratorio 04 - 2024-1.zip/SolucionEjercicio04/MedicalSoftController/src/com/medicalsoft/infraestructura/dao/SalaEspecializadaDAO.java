package com.medicalsoft.infraestructura.dao;

import com.medicalsoft.infraestructura.model.SalaEspecializada;

public interface SalaEspecializadaDAO {
    int insertar(SalaEspecializada salaEspecializada);
}
