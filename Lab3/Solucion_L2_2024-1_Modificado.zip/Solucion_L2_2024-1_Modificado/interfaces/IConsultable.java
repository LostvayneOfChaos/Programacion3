package interfaces;
public interface IConsultable{
	String devolverInformacion();
}