package atenciones;
public enum Plataforma{
	ZOOM, WEBEX
}