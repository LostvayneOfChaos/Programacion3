package atenciones;
public enum EstadoAtencion{
	PROGRAMADA, CONFIRMADA, EN_CURSO, COMPLETADA
}