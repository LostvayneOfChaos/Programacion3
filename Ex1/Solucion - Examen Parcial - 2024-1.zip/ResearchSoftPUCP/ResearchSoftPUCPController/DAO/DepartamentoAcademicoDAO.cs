﻿using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchSoftPUCPController.DAO
{
    public interface DepartamentoAcademicoDAO
    {
        BindingList<DepartamentoAcademico> listarTodos();
    }
}