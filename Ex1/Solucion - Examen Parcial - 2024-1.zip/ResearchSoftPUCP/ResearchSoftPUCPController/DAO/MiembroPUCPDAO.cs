﻿using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchSoftPUCPController.DAO
{
    public interface MiembroPUCPDAO
    {
        BindingList<MiembroPUCP> listarPorNombreCodigoPUCP(string nombreCodigoPUCP);
        BindingList<MiembroPUCP> listarPorIdGrupoInvestigacion(int idGrupoInvestigacion);
    }
}
