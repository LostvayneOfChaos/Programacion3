﻿using MySql.Data.MySqlClient;
using ResearchSoftPUCPController.DAO;
using ResearchSoftPUCPDBManager;
using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchSoftPUCPController.MySQL
{
    public class GrupoInvestigacionMySQL : GrupoInvestigacionDAO
    {
        private MySqlConnection con;
        private MySqlCommand comando;
        private MySqlDataReader lector;
        public int insertar(GrupoInvestigacion grupoInvestigacion)
        {
            int resultado = 0;
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "INSERTAR_GRUPO_INVESTIGACION";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.Add("_id_grupo_investigacion", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                comando.Parameters.AddWithValue("_fid_departamento_academico", grupoInvestigacion.DepartamentoAcademico.IdDepartamentoAcademico);
                comando.Parameters.AddWithValue("_nombre", grupoInvestigacion.Nombre);
                comando.Parameters.AddWithValue("_acronimo", grupoInvestigacion.Acronimo);
                comando.Parameters.AddWithValue("_tipo_investigacion", grupoInvestigacion.TipoInvestigacion.ToString());
                comando.Parameters.AddWithValue("_fecha_fundacion", grupoInvestigacion.FechaFundacion);
                comando.Parameters.AddWithValue("_presupuesto_anual_designado", grupoInvestigacion.PresupuestoAnualDesignado);
                comando.Parameters.AddWithValue("_posee_laboratorio", grupoInvestigacion.PoseeLaboratorio);
                comando.Parameters.AddWithValue("_posee_equipamiento_especializado", grupoInvestigacion.PoseeEquipamientoEspecializado);
                comando.Parameters.AddWithValue("_posee_ambiente_trabajo", grupoInvestigacion.PoseeAmbienteTrabajo);
                comando.Parameters.AddWithValue("_descripcion", grupoInvestigacion.Descripcion);
                comando.Parameters.AddWithValue("_foto", grupoInvestigacion.Foto);
                comando.ExecuteNonQuery();
                grupoInvestigacion.IdGrupoInvestigacion = Int32.Parse(comando.Parameters["_id_grupo_investigacion"].Value.ToString());
                foreach(MiembroPUCP integrante in grupoInvestigacion.Integrantes)
                {
                    comando = new MySqlCommand();
                    comando.Connection = con;
                    comando.CommandText = "INSERTAR_INTEGRANTE_GRUPO_INVESTIGACION";
                    comando.CommandType = System.Data.CommandType.StoredProcedure;
                    comando.Parameters.Add("_id_integrante_grupo_investigacion", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                    comando.Parameters.AddWithValue("_fid_grupo_investigacion", grupoInvestigacion.IdGrupoInvestigacion);
                    comando.Parameters.AddWithValue("_fid_miembro_pucp", integrante.IdMiembroPUCP);
                    comando.ExecuteNonQuery();
                }
                resultado = grupoInvestigacion.IdGrupoInvestigacion;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return resultado;
        }

        public BindingList<GrupoInvestigacion> listarPorNombreAcronimo(string nombreAcronimo)
        {
            BindingList<GrupoInvestigacion> gruposInvestigacion = new BindingList<GrupoInvestigacion>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_GRUPOS_INVESTIGACION_X_NOMBRE_ACRONIMO";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("_nombre_acronimo", nombreAcronimo);
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    GrupoInvestigacion grupoInvestigacion = new GrupoInvestigacion();
                    grupoInvestigacion.IdGrupoInvestigacion = lector.GetInt32("id_grupo_investigacion");
                    grupoInvestigacion.Nombre = lector.GetString("nombre");
                    grupoInvestigacion.Acronimo = lector.GetString("acronimo");
                    gruposInvestigacion.Add(grupoInvestigacion);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return gruposInvestigacion;
        }

        public GrupoInvestigacion obtenerPorID(int idGrupoInvestigacion)
        {
            GrupoInvestigacion grupoInvestigacion = new GrupoInvestigacion();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "OBTENER_GRUPO_INVESTIGACION_X_ID";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("_id_grupo_investigacion", idGrupoInvestigacion);
                lector = comando.ExecuteReader();
                if (lector.Read())
                {
                    grupoInvestigacion.IdGrupoInvestigacion = lector.GetInt32("id_grupo_investigacion");
                    grupoInvestigacion.Nombre = lector.GetString("nombre_grupo");
                    grupoInvestigacion.Acronimo = lector.GetString("acronimo");
                    grupoInvestigacion.TipoInvestigacion = (TipoInvestigacion)Enum.Parse(typeof(TipoInvestigacion),lector.GetString("tipo_investigacion"));
                    grupoInvestigacion.FechaFundacion = lector.GetDateTime("fecha_fundacion");
                    grupoInvestigacion.PresupuestoAnualDesignado = lector.GetDouble("presupuesto_anual_designado");
                    grupoInvestigacion.PoseeLaboratorio = lector.GetBoolean("posee_laboratorio");
                    grupoInvestigacion.PoseeEquipamientoEspecializado = lector.GetBoolean("posee_equipamiento_especializado");
                    grupoInvestigacion.PoseeAmbienteTrabajo = lector.GetBoolean("posee_ambiente_trabajo");
                    grupoInvestigacion.Descripcion = lector.GetString("descripcion");
                    grupoInvestigacion.Foto = (byte[]) lector["foto"];
                    grupoInvestigacion.DepartamentoAcademico = new DepartamentoAcademico();
                    grupoInvestigacion.DepartamentoAcademico.Nombre = lector.GetString("nombre_departamento_academico");
                    grupoInvestigacion.DepartamentoAcademico.IdDepartamentoAcademico = lector.GetInt32("id_departamento_academico");
                    grupoInvestigacion.DepartamentoAcademico.Activo = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return grupoInvestigacion;
        }
    }
}
