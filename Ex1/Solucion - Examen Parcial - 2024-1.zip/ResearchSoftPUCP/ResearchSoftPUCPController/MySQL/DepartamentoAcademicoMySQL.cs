﻿using MySql.Data.MySqlClient;
using ResearchSoftPUCPController.DAO;
using ResearchSoftPUCPDBManager;
using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchSoftPUCPController.MySQL
{
    public class DepartamentoAcademicoMySQL : DepartamentoAcademicoDAO
    {
        private MySqlConnection con;
        private MySqlCommand comando;
        private MySqlDataReader lector;
        public BindingList<DepartamentoAcademico> listarTodos()
        {
            BindingList<DepartamentoAcademico> departamentosAcademicos = new BindingList<DepartamentoAcademico>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_DEPARTAMENTOS_ACADEMICOS_TODOS";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                lector = comando.ExecuteReader();
                while(lector.Read()) {
                    DepartamentoAcademico departamentoAcademico = new DepartamentoAcademico();
                    departamentoAcademico.IdDepartamentoAcademico = lector.GetInt32("id_departamento_academico");
                    departamentoAcademico.Nombre = lector.GetString("nombre");
                    departamentoAcademico.Activo = true;
                    departamentosAcademicos.Add(departamentoAcademico);
                }
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return departamentosAcademicos;
        }
    }
}