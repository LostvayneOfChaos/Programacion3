﻿using MySql.Data.MySqlClient;
using ResearchSoftPUCPController.DAO;
using ResearchSoftPUCPDBManager;
using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResearchSoftPUCPController.MySQL
{
    public class MiembroPUCPMySQL : MiembroPUCPDAO
    {
        private MySqlConnection con;
        private MySqlCommand comando;
        private MySqlDataReader lector;

        public BindingList<MiembroPUCP> listarPorIdGrupoInvestigacion(int idGrupoInvestigacion)
        {
            BindingList<MiembroPUCP> miembrosPUCP = new BindingList<MiembroPUCP>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_INTEGRANTES_X_ID_GRUPO_INVESTIGACION";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("_id_grupo_investigacion", idGrupoInvestigacion);
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    MiembroPUCP miembroPUCP = null;
                    if (lector.GetString("fid_tipo_miembro_pucp").Equals("P"))
                    {
                        miembroPUCP = new Profesor();
                        ((Profesor)miembroPUCP).Dedicacion = lector.GetString("dedicacion");
                    }
                    else
                    {
                        miembroPUCP = new Estudiante();
                        ((Estudiante)miembroPUCP).CRAEST = lector.GetDouble("CRAEST");
                    }
                    miembroPUCP.IdMiembroPUCP = lector.GetInt32("id_miembro_pucp");
                    miembroPUCP.CodigoPUCP = lector.GetString("codigo_pucp");
                    miembroPUCP.Nombre = lector.GetString("nombre");
                    miembroPUCP.ApellidoPaterno = lector.GetString("apellido_paterno");
                    miembrosPUCP.Add(miembroPUCP);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return miembrosPUCP;
        }

        public BindingList<MiembroPUCP> listarPorNombreCodigoPUCP(string nombreCodigoPUCP)
        {
            BindingList<MiembroPUCP> miembrosPUCP = new BindingList<MiembroPUCP>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_MIEMBROS_PUCP_X_NOMBRE_CODIGOPUCP";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("_nombre_codigoPUCP", nombreCodigoPUCP);
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    MiembroPUCP miembroPUCP = null;
                    if (lector.GetString("fid_tipo_miembro_pucp").Equals("P"))
                    {
                        miembroPUCP = new Profesor();
                        ((Profesor) miembroPUCP).Dedicacion = lector.GetString("dedicacion");
                    }
                    else
                    {
                        miembroPUCP = new Estudiante();
                        ((Estudiante) miembroPUCP).CRAEST = lector.GetDouble("CRAEST");
                    }
                    miembroPUCP.IdMiembroPUCP = lector.GetInt32("id_miembro_pucp");
                    miembroPUCP.CodigoPUCP = lector.GetString("codigo_pucp");
                    miembroPUCP.Nombre = lector.GetString("nombre");
                    miembroPUCP.ApellidoPaterno = lector.GetString("apellido_paterno");
                    miembrosPUCP.Add(miembroPUCP); 
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return miembrosPUCP;
        }
    }
}
