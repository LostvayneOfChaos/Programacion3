﻿using ResearchSoftPUCPController.DAO;
using ResearchSoftPUCPController.MySQL;
using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ResearchSoftPUCP
{
    /*
     * Colocar datos:
     * --------------------------------------
     * Código PUCP: 
     * Nombre Completo: 
     */
    public partial class ListarGruposInvestigacion : System.Web.UI.Page
    {
        private GrupoInvestigacionDAO daoGrupoInvestigacion;
        private BindingList<GrupoInvestigacion> gruposInvestigacion;
        protected void Page_Load(object sender, EventArgs e)
        {
            daoGrupoInvestigacion = new GrupoInvestigacionMySQL();
            gruposInvestigacion = daoGrupoInvestigacion.listarPorNombreAcronimo(txtNombreAcronimo.Text);
            gvGruposInvestigacion.DataSource = gruposInvestigacion;
            gvGruposInvestigacion.DataBind();
        }

        protected void lbRegistrar_Click(object sender, EventArgs e)
        {
            Response.Redirect("GestionarGruposInvestigacion.aspx"); ;
        }

        protected void lbVisualizarDatos_Click(object sender, EventArgs e)
        {
            int idGrupoInvestigacion = Int32.Parse(((LinkButton)sender).CommandArgument);
            Session["idGrupoInvestigacion"] = idGrupoInvestigacion;
            Response.Redirect("GestionarGruposInvestigacion.aspx?accion=ver");
        }

        protected void gvGruposInvestigacion_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvGruposInvestigacion.PageIndex = e.NewPageIndex;
            gvGruposInvestigacion.DataBind();
        }
    }
}