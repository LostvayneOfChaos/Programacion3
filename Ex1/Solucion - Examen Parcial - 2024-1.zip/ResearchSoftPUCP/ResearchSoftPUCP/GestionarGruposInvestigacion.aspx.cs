﻿using ResearchSoftPUCPController.DAO;
using ResearchSoftPUCPController.MySQL;
using ResearchSoftPUCPModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ResearchSoftPUCP
{
    /*
     * Colocar datos:
     * --------------------------------------
     * Código PUCP: 
     * Nombre Completo: 
     */
    public partial class GestionarGruposInvestigacion : System.Web.UI.Page
    {
        private byte[] foto;

        private DepartamentoAcademicoDAO daoDepartamentoAcademico;
        private MiembroPUCPDAO daoMiembroPUCP;
        private GrupoInvestigacionDAO daoGrupoInvestigacion;

        private BindingList<MiembroPUCP> miembrosPUCP;
        private GrupoInvestigacion grupoInvestigacion;

        protected void Page_Load(object sender, EventArgs e)
        {
            String accion = Request.QueryString["accion"];
            if (accion != null && accion == "ver" && Session["idGrupoInvestigacion"] != null)
            {
                int idGrupoInvestigacion = (int)Session["idGrupoInvestigacion"];
                grupoInvestigacion = daoGrupoInvestigacion.obtenerPorID(idGrupoInvestigacion);
                grupoInvestigacion.Integrantes = daoMiembroPUCP.listarPorIdGrupoInvestigacion(idGrupoInvestigacion);
                Session["integrantes"] = grupoInvestigacion.Integrantes;
                mostrarDatos();
            }
            else
            {
                grupoInvestigacion = new GrupoInvestigacion();
                if (!IsPostBack)
                {
                    lblTitulo.Text = "Registrar Grupo de Investigación";
                    Session["idGrupoInvestigacion"] = null;
                    Session["foto"] = null;
                    Session["integrantes"] = null;
                    Session["miembroPUCPSeleccionado"] = null;
                }
            }

            if (Session["foto"] != null)
                foto = (byte[]) Session["foto"];
            if (Session["integrantes"] == null)
                grupoInvestigacion.Integrantes = new BindingList<MiembroPUCP>();
            else
                grupoInvestigacion.Integrantes = (BindingList<MiembroPUCP>) Session["integrantes"];

            gvIntegrantes.DataSource = grupoInvestigacion.Integrantes;
            gvIntegrantes.DataBind();

        }

        public void mostrarDatos()
        {
            lblTitulo.Text = "Datos del Grupo de Investigación";
            txtIdGrupo.Text = grupoInvestigacion.IdGrupoInvestigacion.ToString();
            txtNombre.Text = grupoInvestigacion.Nombre;
            txtAcronimo.Text = grupoInvestigacion.Acronimo;
            ddlDepartamento.SelectedValue = grupoInvestigacion.DepartamentoAcademico.IdDepartamentoAcademico.ToString();
            if (grupoInvestigacion.TipoInvestigacion == TipoInvestigacion.BASICA)
                rbBasica.Checked = true;
            else
                rbAplicada.Checked = true;
            cbLaboratorio.Checked = grupoInvestigacion.PoseeLaboratorio;
            cbEquipamiento.Checked = grupoInvestigacion.PoseeEquipamientoEspecializado;
            cbAmbienteTrabajo.Checked = grupoInvestigacion.PoseeAmbienteTrabajo;
            dtpFechaFundacion.Text = grupoInvestigacion.FechaFundacion.ToString("yyyy-MM-dd");
            txtPresupuestoAnual.Text = grupoInvestigacion.PresupuestoAnualDesignado.ToString("N2");
            txtDescripcion.Value = grupoInvestigacion.Descripcion;

            string base64String = Convert.ToBase64String(grupoInvestigacion.Foto);
            string imageUrl = "data:image/jpeg;base64," + base64String;

            imgFotoGrupo.ImageUrl = imageUrl;

            txtNombre.Enabled = false;
            txtAcronimo.Enabled = false;
            ddlDepartamento.Enabled = false;
            btnGuardar.Visible = false;
            btnSubirFotoGrupo.Visible = false;
            fileUploadFotoGrupo.Visible = false;
            rbBasica.Disabled = true;
            rbAplicada.Disabled = true;
            cbLaboratorio.Disabled = true;
            cbEquipamiento.Disabled = true;
            cbAmbienteTrabajo.Disabled = true;
            dtpFechaFundacion.Enabled = false;
            txtPresupuestoAnual.Enabled = false;
            txtDescripcion.Disabled = true;
            lbBuscarIntegrante.Visible = false;
            lbAgregarIntegrante.Visible = false;
            gvIntegrantes.Columns[4].Visible = false;
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            daoDepartamentoAcademico = new DepartamentoAcademicoMySQL();
            daoMiembroPUCP = new MiembroPUCPMySQL();
            daoGrupoInvestigacion = new GrupoInvestigacionMySQL();

            miembrosPUCP = daoMiembroPUCP.listarPorNombreCodigoPUCP(txtNombreCodigoPUCP.Text);

            ddlDepartamento.DataSource = daoDepartamentoAcademico.listarTodos();
            ddlDepartamento.DataTextField = "Nombre";
            ddlDepartamento.DataValueField = "IdDepartamentoAcademico";
            ddlDepartamento.DataBind();
        }
        protected void btnSubirFotoGrupo_Click(object sender, EventArgs e)
        {
            //Verificar si se seleccionó un archivo
            if (fileUploadFotoGrupo.HasFile)
            {
                // Obtener la extensión del archivo
                string extension = System.IO.Path.GetExtension(fileUploadFotoGrupo.FileName);
                // Verificar si el archivo es una imagen
                if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif")
                {
                    // Guardar la imagen en el servidor
                    string filename = Guid.NewGuid().ToString() + extension;
                    string filePath = Server.MapPath("~/Uploads/") + filename;
                    fileUploadFotoGrupo.SaveAs(Server.MapPath("~/Uploads/") + filename);
                    // Mostrar la imagen en la página
                    imgFotoGrupo.ImageUrl = "~/Uploads/" + filename;
                    imgFotoGrupo.Visible = true;
                    // Guardamos la referencia en una variable de sesión llamada foto
                    FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Session["foto"] = br.ReadBytes((int)fs.Length);
                    fs.Close();
                }
                else
                {
                    // Mostrar un mensaje de error si el archivo no es una imagen
                    Response.Write("Por favor, selecciona un archivo de imagen válido.");
                }
            }
            else
            {
                // Mostrar un mensaje de error si no se seleccionó ningún archivo
                Response.Write("Por favor, selecciona un archivo de imagen.");
            }
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void lbBuscarIntegrante_Click(object sender, EventArgs e)
        {
            string script = "window.onload = function() { showModalForm() };";
            ClientScript.RegisterStartupScript(GetType(), "", script, true);
        }

        protected void lbBuscarMiembroPUCPModal_Click(object sender, EventArgs e)
        {
            miembrosPUCP = daoMiembroPUCP.listarPorNombreCodigoPUCP(txtNombreCodigoPUCP.Text);
            gvMiembrosPUCP.DataSource = miembrosPUCP;
            gvMiembrosPUCP.DataBind();
        }

        protected void gvMiembrosPUCP_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMiembrosPUCP.PageIndex = e.NewPageIndex;
            gvMiembrosPUCP.DataSource = miembrosPUCP;
            gvMiembrosPUCP.DataBind();
        }

        protected void lbSeleccionarMiembroPUCP_Click(object sender, EventArgs e)
        {
            int idMiembroPUCP = Int32.Parse(((LinkButton)sender).CommandArgument);
            MiembroPUCP miembroPUCPSeleccionado = miembrosPUCP.SingleOrDefault(x => x.IdMiembroPUCP == idMiembroPUCP);
            Session["miembroPUCPSeleccionado"] = miembroPUCPSeleccionado;
            txtNombreIntegrante.Text = miembroPUCPSeleccionado.NombreCompleto;
            ScriptManager.RegisterStartupScript(this, GetType(), "", "__doPostBack('','');", true);
        }

        protected void lbAgregarIntegrante_Click(object sender, EventArgs e)
        {
            grupoInvestigacion.Integrantes.Add((MiembroPUCP) Session["miembroPUCPSeleccionado"]);
            Session["integrantes"] = grupoInvestigacion.Integrantes;
            gvIntegrantes.DataSource = grupoInvestigacion.Integrantes;
            gvIntegrantes.DataBind();
            txtNombreIntegrante.Text = "";
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            
            grupoInvestigacion.Nombre = txtNombre.Text;
            grupoInvestigacion.Acronimo = txtAcronimo.Text;
            grupoInvestigacion.Foto = foto;
            grupoInvestigacion.FechaFundacion = DateTime.Parse(dtpFechaFundacion.Text);
            grupoInvestigacion.DepartamentoAcademico = new DepartamentoAcademico();
            grupoInvestigacion.DepartamentoAcademico.IdDepartamentoAcademico = Int32.Parse(ddlDepartamento.SelectedValue);
            if (rbBasica.Checked)
                grupoInvestigacion.TipoInvestigacion = TipoInvestigacion.BASICA;
            else
                grupoInvestigacion.TipoInvestigacion = TipoInvestigacion.APLICADA;
            grupoInvestigacion.PresupuestoAnualDesignado = Double.Parse(txtPresupuestoAnual.Text);
            grupoInvestigacion.Descripcion = txtDescripcion.Value;
            grupoInvestigacion.PoseeLaboratorio = cbLaboratorio.Checked;
            grupoInvestigacion.PoseeEquipamientoEspecializado = cbEquipamiento.Checked;
            grupoInvestigacion.PoseeAmbienteTrabajo = cbAmbienteTrabajo.Checked;
            int resultado = daoGrupoInvestigacion.insertar(grupoInvestigacion);
            if (resultado != 0)
            {
                Response.Redirect("ListarGruposInvestigacion.aspx");
                Response.Write("Se ha registrado con exito...");
            }
        }

        protected void gvIntegrantes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvIntegrantes.PageIndex = e.NewPageIndex;
            gvIntegrantes.DataBind();
        }

        protected void lbEliminarIntegrante_Click(object sender, EventArgs e)
        {
            int idMiembroPUCP = Int32.Parse(((LinkButton)sender).CommandArgument);
            MiembroPUCP miembroPUCPEliminar = grupoInvestigacion.Integrantes.SingleOrDefault(x => x.IdMiembroPUCP == idMiembroPUCP);
            grupoInvestigacion.Integrantes.Remove(miembroPUCPEliminar);
            Session["integrantes"] = grupoInvestigacion.Integrantes;
            gvIntegrantes.DataBind();
        }
    }
}