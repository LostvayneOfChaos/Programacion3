﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GameSoft
{
    /* Colocar sus datos personales
     * ------------------------------------------------
     * Nombre Completo:
     * Codigo PUCP:
     * ------------------------------------------------
     */
    public partial class RegistrarPokemon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String accion = Request.QueryString["accion"];
            String idPokemon = Request.QueryString["idPokemon"];
            if (accion != null && accion == "ver" && idPokemon != null)
            {
                lblTitulo.Text = "Visualizar Pokémon";
                //Completar
                deshabilitarCampos();
            }
            else
                lblTitulo.Text = "Registrar Pokémon";

            if (IsPostBack && fileUploadFotoPokemon.PostedFile != null && fileUploadFotoPokemon.HasFile)
            {
                string extension = System.IO.Path.GetExtension(fileUploadFotoPokemon.FileName);
                if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif")
                {
                    string filename = Guid.NewGuid().ToString() + extension;
                    string filePath = Server.MapPath("~/Uploads/") + filename;
                    fileUploadFotoPokemon.SaveAs(Server.MapPath("~/Uploads/") + filename);
                    imgFotoPokemon.ImageUrl = "~/Uploads/" + filename;
                    imgFotoPokemon.Visible = true;
                    FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Session["foto"] = br.ReadBytes((int)fs.Length);
                    fs.Close();
                }
                else
                {
                    Response.Write("Por favor, selecciona un archivo de imagen válido.");
                }
            }
        }

        public void deshabilitarCampos()
        {
            txtNroPokedex.Enabled = false;
            txtNombre.Enabled = false;
            ddlTipo1.Enabled = false;
            ddlTipo2.Enabled = false;
            txtDescripcion.Disabled = true;
            txtPeso.Enabled = false;
            txtAltura.Enabled = false;
            rbPrimeraGeneracion.Disabled = true;
            rbSegundaGeneracion.Disabled = true;
            rbTerceraGeneracion.Disabled = true;
            fileUploadFotoPokemon.Enabled = false;
            btnGuardar.Visible = false;
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListarPokemon.aspx");
        }
    }
}