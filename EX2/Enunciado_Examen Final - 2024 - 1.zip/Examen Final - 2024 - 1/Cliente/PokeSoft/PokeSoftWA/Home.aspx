﻿<%@ Page Title="" Language="C#" MasterPageFile="~/PokeSoft.Master" AutoEventWireup="true" CodeBehind="Home.aspx.cs" Inherits="GameSoft.Home" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cphTitulo" runat="server">
    Home
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cphScripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cphContenido" runat="server">
    <h1>Examen Final</h1>
</asp:Content>