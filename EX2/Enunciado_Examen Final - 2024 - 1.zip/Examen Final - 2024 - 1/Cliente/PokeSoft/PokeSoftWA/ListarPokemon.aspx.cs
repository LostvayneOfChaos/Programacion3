﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GameSoft
{
    /* Colocar sus datos personales
     * ------------------------------------------------
     * Nombre Completo:
     * Codigo PUCP:
     * ------------------------------------------------
     */
    public partial class ListarPokemons : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lbRegistrar_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegistrarPokemon.aspx");
        }

        protected void lbVisualizar_Click(object sender, EventArgs e)
        {
            int idPokemon = Int32.Parse(((LinkButton)sender).CommandArgument);
            Response.Redirect("RegistrarPokemon.aspx?accion=ver&idPokemon=" + idPokemon.ToString());
        }
    }
}