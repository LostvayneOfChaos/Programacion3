﻿<%@ Page Title="" Language="C#" MasterPageFile="~/PokeSoft.Master" AutoEventWireup="true" CodeBehind="RegistrarPokemon.aspx.cs" Inherits="GameSoft.RegistrarPokemon" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cphTitulo" runat="server">
    Registrar Pokémon
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="cphScripts" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cphContenido" runat="server">
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>
                    <!-- Cambiar el titulo dependiendo de si se registran o muestran datos -->
                    <asp:Label ID="lblTitulo" runat="server" Text="lblTitulo"></asp:Label>
                </h2>
            </div>
            <div class="card-body pb-2">
                <div class="row">
                    <div class="col-md-6">
                        <asp:Panel ID="panel1" CssClass="p-3" runat="server" BorderStyle="Solid" BorderColor="LightGray">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <asp:Label ID="lblNroPokedex" CssClass="col-form-label" runat="server" Text="Nro Pokedex:"></asp:Label>
                                    <asp:TextBox ID="txtNroPokedex" CssClass="form-control" runat="server"></asp:TextBox>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <asp:Label ID="lblNombre" CssClass="col-form-label" runat="server" Text="Nombre:"></asp:Label>
                                    <asp:TextBox ID="txtNombre" CssClass="form-control" runat="server"></asp:TextBox>
                                </div>
                            </div>
                        </asp:Panel>
                    </div>
                    <div class="col-md-6">
                        <asp:Panel ID="panel2" CssClass="ps-3" runat="server" BorderStyle="Solid" BorderColor="LightGray" >
                            <div class="row mt-1">
                                <div class="row mt-1 pe-2 ps-3">
                                    <asp:Panel ID="panelTipo1" CssClass="panel-con-altura" runat="server" BorderStyle="Solid" BorderColor="LightGray"></asp:Panel>
                                </div>
                                <div class="row mt-1 pe-0 ps-3">
                                    <div class="col-3 p-0">
                                        <div class="center h-100 w-100">
                                            <asp:Image ID="imgTipo1" alt="Foto del Tipo 1" runat="server" CssClass="img-fluid img-thumbnail h-84 w-100" Height="84" ImageUrl="/Images/placeholder.jpg" />
                                        </div>
                                    </div>
                                    <div class="col-9">
                                        <asp:Label ID="lblTipo1" CssClass="col-form-label col-auto" runat="server" Text="Tipo 1:"></asp:Label>
                                        <div class="col-12">
                                            <asp:DropDownList ID="ddlTipo1" CssClass="form-select" runat="server" AutoPostBack="true"></asp:DropDownList>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-1 mb-1">
                                <div class="row mt-1 pe-2 ps-3">
                                    <asp:Panel ID="panelTipo2" CssClass="panel-con-altura" runat="server" BorderStyle="Solid" BorderColor="LightGray"></asp:Panel>
                                </div>
                                <div class="row mt-1 pe-0 ps-3">
                                    <div class="col-3 p-0">
                                        <div class="center h-100 w-100">
                                            <asp:Image ID="imgTipo2" alt="Foto del Tipo 2" runat="server" CssClass="img-fluid img-thumbnail h-84 w-100" Height="84" ImageUrl="/Images/placeholder.jpg" />
                                        </div>
                                    </div>
                                    <div class="col-9">
                                        <asp:Label ID="lblTipo2" CssClass="col-form-label col-auto" runat="server" Text="Tipo 2:"></asp:Label>
                                        <div class="col-12">
                                            <asp:DropDownList ID="ddlTipo2" CssClass="form-select" runat="server" AutoPostBack="true"></asp:DropDownList>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </asp:Panel>
                    </div>   
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <asp:Image ID="imgFotoPokemon" Height="231" Width="323" runat="server" CssClass="img-fluid img-thumbnail" ImageUrl="/Images/placeholder.jpg" />
                        <asp:FileUpload ID="fileUploadFotoPokemon" CssClass="form-control mb-2" runat="server" onchange="this.form.submit()" ClientIDMode="Static" />
                    </div>
                    <div class="col-md-8 mt-2">
                        <asp:Panel ID="panel3" CssClass="p-2" runat="server" BorderStyle="Solid" BorderColor="LightGray">
                            <div class="col-md-12">
                                <asp:Label ID="lblDescripcion" CssClass="col-form-label" runat="server" Text="Descripción:"></asp:Label>
                                <textarea id="txtDescripcion" runat="server" class="form-control" cols="20" rows="2"></textarea>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <asp:Label ID="lblPeso" CssClass="col-form-label" runat="server" Text="Peso (kg.):"></asp:Label>
                                        <asp:TextBox ID="txtPeso" CssClass="form-control" runat="server"></asp:TextBox>
                                    </div>
                                    <div class="col-md-6">
                                        <asp:Label ID="lblAltura" CssClass="col-form-label" runat="server" Text="Altura (m.):"></asp:Label>
                                        <asp:TextBox ID="txtAltura" CssClass="form-control" runat="server"></asp:TextBox>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <asp:Label ID="lblGeneracion" CssClass="col-form-label" runat="server" Text="Generación:"></asp:Label>
                                <div class="form-control">
                                    <div class="form-check form-check-inline">
                                        <input id="rbPrimeraGeneracion" class="form-check-input" type="radio" runat="server" />
                                        <label id="lblPrimeraGeneracion" class="form-check-label" for="cphContenido_rbPrimeraGeneracion">Primera Generacion</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input id="rbSegundaGeneracion" class="form-check-input" type="radio" runat="server" />
                                        <label id="lblSegundaGeneracion" class="form-check-label" for="cphContenido_rbSegundaGeneracion">Segunda Generacion</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input id="rbTerceraGeneracion" class="form-check-input" type="radio" runat="server" />
                                        <label id="lblTerceraGeneracion" class="form-check-label" for="cphContenido_rbTerceraGeneracion">Tercera Generacion</label>
                                    </div>
                                </div>
                            </div>
                        </asp:Panel>
                    </div>
                </div>
            </div>
            <div class="card-footer clearfix">
                <asp:Button ID="btnRegresar" runat="server" Text="Regresar" CssClass="float-start btn btn-secondary" OnClick="btnRegresar_Click"/>
                <asp:Button ID="btnGuardar" runat="server" Text="Guardar" CssClass="float-end btn btn-primary" />
            </div>
        </div>
    </div>
</asp:Content>