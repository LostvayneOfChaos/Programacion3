package pe.edu.pucp.pokesoft.services;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;

/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/

@WebService(serviceName = "TipoElementalWS")
public class TipoElementalWS {

    @WebMethod(operationName = "helloTipoElemental")
    public String helloTipoElemental(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
}