package pe.edu.pucp.pokesoft.services;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;

/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/

@WebService(serviceName = "PokemonWS")
public class PokemonWS {

    @WebMethod(operationName = "helloPokemon")
    public String helloPokemon(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
}
