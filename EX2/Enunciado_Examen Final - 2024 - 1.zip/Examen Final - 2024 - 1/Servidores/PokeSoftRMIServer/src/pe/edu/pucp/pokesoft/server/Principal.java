package pe.edu.pucp.pokesoft.server;
/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/
public class Principal {
    public static void main(String[] args){
        
    }
}