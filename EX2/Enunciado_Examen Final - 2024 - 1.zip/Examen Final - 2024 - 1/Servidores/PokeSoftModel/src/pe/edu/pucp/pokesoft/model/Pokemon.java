package pe.edu.pucp.pokesoft.model;
public class Pokemon {
    private int idPokemon;
    private String numeroPokedexNacional;
    private String nombre;
    private TipoElemental tipoElemental1;
    private TipoElemental tipoElemental2;
    private String descripcion;
    private double peso;
    private double altura;
    private Generacion generacion;
    private byte[] foto;
    private boolean activo;

    public int getIdPokemon() {
        return idPokemon;
    }

    public void setIdPokemon(int idPokemon) {
        this.idPokemon = idPokemon;
    }

    public String getNumeroPokedexNacional() {
        return numeroPokedexNacional;
    }

    public void setNumeroPokedexNacional(String numeroPokedexNacional) {
        this.numeroPokedexNacional = numeroPokedexNacional;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoElemental getTipoElemental1() {
        return tipoElemental1;
    }

    public void setTipoElemental1(TipoElemental tipoElemental1) {
        this.tipoElemental1 = tipoElemental1;
    }

    public TipoElemental getTipoElemental2() {
        return tipoElemental2;
    }

    public void setTipoElemental2(TipoElemental tipoElemental2) {
        this.tipoElemental2 = tipoElemental2;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public Generacion getGeneracion() {
        return generacion;
    }

    public void setGeneracion(Generacion generacion) {
        this.generacion = generacion;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
}