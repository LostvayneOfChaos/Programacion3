package pe.edu.pucp.pokesoft.model;
public enum Generacion {
    PRIMERA, SEGUNDA, TERCERA
}