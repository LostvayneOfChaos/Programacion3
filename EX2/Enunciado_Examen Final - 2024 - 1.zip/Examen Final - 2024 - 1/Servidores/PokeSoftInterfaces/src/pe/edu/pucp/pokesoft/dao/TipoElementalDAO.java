package pe.edu.pucp.pokesoft.dao;
import java.util.ArrayList;
import pe.edu.pucp.pokesoft.model.TipoElemental;
public interface TipoElementalDAO {
    ArrayList<TipoElemental> listarTodos();
}
