package pe.edu.pucp.pokesoft.dao;
import java.util.ArrayList;
import pe.edu.pucp.pokesoft.model.Pokemon;
public interface PokemonDAO {
    int insertar(Pokemon pokemon);
    ArrayList<Pokemon> listarPorNombre(String nombre);
    Pokemon obtenerPorId(int idPokemon);
}