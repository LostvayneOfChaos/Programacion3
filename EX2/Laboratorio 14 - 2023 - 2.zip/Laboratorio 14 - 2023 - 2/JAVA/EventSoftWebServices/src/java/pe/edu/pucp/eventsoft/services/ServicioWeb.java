package pe.edu.pucp.eventsoft.services;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "ServicioWeb")
public class ServicioWeb {

    /* Coloque su nombre y código
    ----------------------------------------------------------------
    Nombre Completo:
    Código PUCP:
    */
    
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
}
