﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventSoft
{
    public partial class frmBusquedaEstablecimientos : Form
    {
        public frmBusquedaEstablecimientos()
        {
            InitializeComponent();
        }
    }
}
