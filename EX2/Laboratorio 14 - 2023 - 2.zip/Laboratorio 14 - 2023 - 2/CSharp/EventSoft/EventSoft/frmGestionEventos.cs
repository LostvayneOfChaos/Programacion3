﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventSoft
{
    /* Coloque su nombre completo y código
     * Nombre Completo:
     * Código PUCP:
     */
    public partial class frmGestionEventos : Form
    {
        private Estado _estado;
        private string _rutaFoto;
        public frmGestionEventos()
        {
            InitializeComponent();
            _estado = Estado.Inicial;
            establecerEstadoComponentes();
        }

        public void establecerEstadoComponentes()
        {
            switch (_estado)
            {
                case Estado.Inicial:
                    btnNuevo.Enabled = true;
                    btnGuardar.Enabled = false;
                    btnBuscar.Enabled = true;
                    btnCancelar.Enabled = true;
                    btnBuscarArtista.Enabled = false;
                    btnBuscarEstablecimiento.Enabled = false;
                    btnSubirFoto.Enabled = false;
                    txtIDEvento.Enabled = false;
                    txtIDEvento.ReadOnly = true;
                    txtNombreEvento.Enabled = false;
                    txtNombreEvento.ReadOnly = false;
                    rbConcierto.Enabled = false;
                    rbTeatro.Enabled = false;
                    txtArtista.Enabled = false;
                    txtArtista.ReadOnly = true;
                    txtEstablecimiento.Enabled = false;
                    txtEstablecimiento.ReadOnly = true;
                    dtpFechaEvento.Enabled = false;
                    dtpHoraEvento.Enabled = false;
                    txtCostoRealizacion.Enabled = false;
                    txtCostoRealizacion.ReadOnly = false;
                    txtCantEntradasDisp.Enabled = false;
                    txtCantEntradasDisp.ReadOnly = false;
                    txtDescripcion.Enabled = false;
                    txtDescripcion.ReadOnly = false;
                    break;
                case Estado.Nuevo:
                    btnNuevo.Enabled = false;
                    btnGuardar.Enabled = true;
                    btnBuscar.Enabled = false;
                    btnCancelar.Enabled = true;
                    btnBuscarArtista.Enabled = true;
                    btnBuscarEstablecimiento.Enabled = true;
                    btnSubirFoto.Enabled = true;
                    txtIDEvento.Enabled = true;
                    txtIDEvento.ReadOnly = true;
                    txtNombreEvento.Enabled = true;
                    txtNombreEvento.ReadOnly = false;
                    rbConcierto.Enabled = true;
                    rbTeatro.Enabled = true;
                    txtArtista.Enabled = true;
                    txtArtista.ReadOnly = true;
                    txtEstablecimiento.Enabled = true;
                    txtEstablecimiento.ReadOnly = true;
                    dtpFechaEvento.Enabled = true;
                    dtpHoraEvento.Enabled = true;
                    txtCostoRealizacion.Enabled = true;
                    txtCostoRealizacion.ReadOnly = false;
                    txtCantEntradasDisp.Enabled = true;
                    txtCantEntradasDisp.ReadOnly = false;
                    txtDescripcion.Enabled = true;
                    txtDescripcion.ReadOnly = false;
                    break;
                case Estado.Buscar:
                    btnNuevo.Enabled = false;
                    btnGuardar.Enabled = false;
                    btnBuscar.Enabled = false;
                    btnCancelar.Enabled = true;
                    btnBuscarArtista.Enabled = false;
                    btnBuscarEstablecimiento.Enabled = false;
                    btnSubirFoto.Enabled = false;
                    txtIDEvento.Enabled = true;
                    txtIDEvento.ReadOnly = true;
                    txtNombreEvento.Enabled = true;
                    txtNombreEvento.ReadOnly = true;
                    rbConcierto.Enabled = false;
                    rbTeatro.Enabled = false;
                    txtArtista.Enabled = true;
                    txtArtista.ReadOnly = true;
                    txtEstablecimiento.Enabled = true;
                    txtEstablecimiento.ReadOnly = true;
                    dtpFechaEvento.Enabled = false;
                    dtpHoraEvento.Enabled = false;
                    txtCostoRealizacion.Enabled = true;
                    txtCostoRealizacion.ReadOnly = true;
                    txtCantEntradasDisp.Enabled = true;
                    txtCantEntradasDisp.ReadOnly = true;
                    txtDescripcion.Enabled = true;
                    txtDescripcion.ReadOnly = true;
                    break;
            }
        }

        public void limpiarComponentes()
        {
            txtIDEvento.Text = "";
            txtNombreEvento.Text = "";
            rbConcierto.Checked = false;
            rbTeatro.Checked = false;
            txtArtista.Text = "";
            txtEstablecimiento.Text = "";
            dtpFechaEvento.Value = DateTime.Now;
            dtpHoraEvento.Value = DateTime.Now;
            txtCostoRealizacion.Text = "";
            txtCantEntradasDisp.Text = "";
            txtDescripcion.Text = "";
            pbFoto.Image = null;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            limpiarComponentes();
            _estado = Estado.Inicial;
            establecerEstadoComponentes();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            limpiarComponentes();
            _estado = Estado.Nuevo;
            establecerEstadoComponentes();
        }

        private void btnSubirFoto_Click(object sender, EventArgs e)
        {
            try
            {
                if (ofdFoto.ShowDialog() == DialogResult.OK)
                {
                    _rutaFoto = ofdFoto.FileName;
                    pbFoto.Image = Image.FromFile(_rutaFoto);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("El archivo seleccionado no es un tipo de imagen válido");
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            _estado = Estado.Buscar;
            establecerEstadoComponentes();
        }
    }
}
