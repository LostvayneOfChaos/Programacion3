package pe.edu.pucp.gamesoft.model;
public enum Clasificacion {
    EVERYONE, TEEN, MATURE, ADULTSONLY
}
