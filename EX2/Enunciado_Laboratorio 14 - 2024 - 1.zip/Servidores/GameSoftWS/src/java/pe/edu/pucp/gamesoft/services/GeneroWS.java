package pe.edu.pucp.gamesoft.services;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/

@WebService(serviceName = "GeneroWS", targetNamespace = "http://services.gamesoft.pucp.edu.pe/")
public class GeneroWS {
    @WebMethod(operationName = "helloGenero")
    public String helloGenero(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
}