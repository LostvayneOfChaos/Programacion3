package pe.edu.pucp.gamesoft.services;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/

@WebService(serviceName = "VideojuegoWS", targetNamespace = "http://services.gamesoft.pucp.edu.pe/")
public class VideojuegoWS {
    @WebMethod(operationName = "helloVideojuego")
    public String helloVideojuego(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
}