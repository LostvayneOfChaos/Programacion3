package pe.edu.pucp.gamesoft.dao;

import java.util.ArrayList;
import pe.edu.pucp.gamesoft.model.Genero;

public interface GeneroDAO {
    ArrayList<Genero> listarTodos();
}
