package pe.edu.pucp.gamesoft.dao;
import java.util.ArrayList;
import pe.edu.pucp.gamesoft.model.Videojuego;
public interface VideojuegoDAO {
    int insertar(Videojuego videojuego);
    ArrayList<Videojuego> listarPorNombre(String nombre);
    Videojuego obtenerPorId(int idVideojuego);
}