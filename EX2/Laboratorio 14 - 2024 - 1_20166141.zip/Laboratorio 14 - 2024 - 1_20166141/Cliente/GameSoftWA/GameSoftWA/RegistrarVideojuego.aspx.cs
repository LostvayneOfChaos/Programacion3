﻿using GameSoftWA.Servicio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GameSoftWA
{
    /* Colocar sus datos personales
     * ------------------------------------------------
     * Nombre Completo:
     * Codigo PUCP:
     * ------------------------------------------------
     */
    
    public partial class RegistrarVideojuego : System.Web.UI.Page
    {
        private Servicio.GeneroWSClient daoGenero;
        private Servicio.VideojuegoWSClient daoVideojuego;
        private BindingList<Servicio.genero> generos;
        private Servicio.videojuego videojuegoActual;
        protected void Page_Load(object sender, EventArgs e)
        {
            daoGenero = new Servicio.GeneroWSClient();
            daoVideojuego = new Servicio.VideojuegoWSClient();
            String accion = Request.QueryString["accion"];
            String idVideojuego = Request.QueryString["idVideojuego"];
            if (!IsPostBack)
            {

                //generos = new BindingList<Servicio.genero>(daoGenero.listarTodos()? new BindingList<Servicio.genero>()??.ToList());
                ddlGenero.DataSource = new BindingList<genero>(daoGenero.listarTodos()?.ToList() ?? new List<genero>());
                ddlGenero.DataTextField = "nombre";
                ddlGenero.DataValueField = "idGenero";
                ddlGenero.DataBind();
            }
            if (accion != null && accion == "ver" && idVideojuego != null)
            {
                lblTitulo.Text = "Visualizar Videojuego";
                //Completar para ver el videojuego
                videojuegoActual = daoVideojuego.obtenerPorId(Int32.Parse(idVideojuego));
                txtNombre.Text =videojuegoActual.nombre;
                txtIdVideojuego.Text = videojuegoActual.idVideojuego.ToString();
                txtCostoDesarrollo.Text = videojuegoActual.costoDesarrollo.ToString("N2");
                ddlGenero.SelectedValue = videojuegoActual.genero.idGenero.ToString();
                if (videojuegoActual.clasificacion == Servicio.clasificacion.EVERYONE) rbEveryone.Checked = true;
                else if (videojuegoActual.clasificacion == Servicio.clasificacion.TEEN) rbTeen.Checked = true;
                else if (videojuegoActual.clasificacion == Servicio.clasificacion.MATURE) rbMature.Checked = true;
                else if (videojuegoActual.clasificacion == Servicio.clasificacion.ADULTSONLY) rbAdultsOnly.Checked = true;
                if(videojuegoActual.foto != null)
                {
                    string base64String = Convert.ToBase64String(videojuegoActual.foto);
                    string imageUrl = "data:image/jpeg;base64," + base64String;
                    imgFotoVideojuego.ImageUrl = imageUrl;
                }
                
                dtpFechaLanzamiento.Value = videojuegoActual.fechaLanzamiento.ToString("yyyy-MM-dd");
                deshabilitarCampos();
            }
            else { 
                lblTitulo.Text = "Registrar Videojuego";
            }
                
            if (IsPostBack && fileUploadFotoVideojuego.PostedFile != null && fileUploadFotoVideojuego.HasFile)
            {
                string extension = System.IO.Path.GetExtension(fileUploadFotoVideojuego.FileName);
                if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif")
                {
                    string filename = Guid.NewGuid().ToString() + extension;
                    string filePath = Server.MapPath("~/Uploads/") + filename;
                    fileUploadFotoVideojuego.SaveAs(Server.MapPath("~/Uploads/") + filename);
                    imgFotoVideojuego.ImageUrl = "~/Uploads/" + filename;
                    imgFotoVideojuego.Visible = true;
                    FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Session["foto"] = br.ReadBytes((int)fs.Length);
                    fs.Close();
                }
                else
                {
                    Response.Write("Por favor, selecciona un archivo de imagen válido.");
                }
            }
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListarVideojuegos.aspx");
        }

        public void deshabilitarCampos()
        {
            txtNombre.Enabled = false;
            ddlGenero.Enabled = false;
            dtpFechaLanzamiento.Disabled = true;
            txtCostoDesarrollo.Enabled = false;
            fileUploadFotoVideojuego.Enabled = false;
            rbEveryone.Disabled = true;
            rbTeen.Disabled = true;
            rbMature.Disabled = true;
            rbAdultsOnly.Disabled = true;
            btnGuardar.Visible = false;
        }

        protected void ddlGenero_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            videojuegoActual = new Servicio.videojuego();
            videojuegoActual.costoDesarrollo = Double.Parse(txtCostoDesarrollo.Text);
            videojuegoActual.genero = new Servicio.genero();
            videojuegoActual.genero.idGenero = Int32.Parse(ddlGenero.SelectedValue);
            videojuegoActual.nombre=txtNombre.Text;
            if (rbEveryone.Checked == true)
                videojuegoActual.clasificacion = Servicio.clasificacion.EVERYONE;
            else if (rbAdultsOnly.Checked == true)
                videojuegoActual.clasificacion = Servicio.clasificacion.ADULTSONLY;
            else if (rbTeen.Checked == true)
                videojuegoActual.clasificacion = Servicio.clasificacion.TEEN;
            else if (rbMature.Checked == true)
                videojuegoActual.clasificacion = Servicio.clasificacion.MATURE;
            videojuegoActual.clasificacionSpecified = true;
            videojuegoActual.foto = (byte[])Session["foto"];
            videojuegoActual.fechaLanzamiento = DateTime.Parse(dtpFechaLanzamiento.Value);
            videojuegoActual.fechaLanzamientoSpecified = true;
            daoVideojuego.insertar(videojuegoActual);
            Response.Redirect("ListarVideojuegos.aspx");

        }
    }
}