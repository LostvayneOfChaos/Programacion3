package pe.edu.pucp.gamesoft.services;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import java.util.ArrayList;
import pe.edu.pucp.gamesoft.dao.VideojuegoDAO;
import java.rmi.Naming;
import pe.edu.pucp.gamesoft.model.Videojuego;
/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/

@WebService(serviceName = "VideojuegoWS", targetNamespace = "http://services.gamesoft.pucp.edu.pe/")
public class VideojuegoWS {
    private VideojuegoDAO daoVideojuego;
    
    @WebMethod(operationName = "insertar")
    public int insertar(@WebParam(name = "videojuego") Videojuego videojuego) {
        int resultado = 0;
        try{
            daoVideojuego = (VideojuegoDAO)
                    Naming.lookup("//127.0.0.1:1234"+
                            "/daoVideojuego");
            resultado = daoVideojuego.insertar(videojuego);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
    @WebMethod(operationName = "listarPorNombre")
    public ArrayList<Videojuego> listarPorNombre(@WebParam(name = "nombre") String nombre) {
        ArrayList<Videojuego> videojuegos = null;
        try{
            daoVideojuego = (VideojuegoDAO)
                    Naming.lookup("//127.0.0.1:1234"+
                            "/daoVideojuego");
            videojuegos = daoVideojuego.listarPorNombre(nombre);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return videojuegos;
    }
    
    @WebMethod(operationName = "obtenerPorId")
    public Videojuego obtenerPorId(@WebParam(name = "idVideojuego") int idVideojuego) {
        Videojuego videojuego = null;
        try{
            daoVideojuego = (VideojuegoDAO)
                    Naming.lookup("//127.0.0.1:1234"+
                            "/daoVideojuego");
            videojuego = daoVideojuego.obtenerPorId(idVideojuego);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return videojuego;
    }
    
    
}