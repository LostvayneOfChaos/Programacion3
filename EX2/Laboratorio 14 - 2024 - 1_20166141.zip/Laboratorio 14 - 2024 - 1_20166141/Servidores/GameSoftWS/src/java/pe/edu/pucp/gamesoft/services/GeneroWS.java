package pe.edu.pucp.gamesoft.services;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import java.util.ArrayList;
import pe.edu.pucp.gamesoft.dao.GeneroDAO;
import java.rmi.Naming;
import pe.edu.pucp.gamesoft.model.Genero;
/* Colocar sus datos personales
* ------------------------------------------------
* Nombre Completo:
* Codigo PUCP:
* ------------------------------------------------
*/

@WebService(serviceName = "GeneroWS", targetNamespace = "http://services.gamesoft.pucp.edu.pe/")
public class GeneroWS {
    private GeneroDAO daoGenero;
    
    @WebMethod(operationName = "listarTodos")
    public ArrayList<Genero> listarTodos() {
        ArrayList<Genero> generos = null;
        try{
            daoGenero = (GeneroDAO)
                    Naming.lookup("//127.0.0.1:1234"+
                            "/daoGenero");
            generos = daoGenero.listarTodos();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return generos;
        
        
        
    }
    
    
    
    
    
    
}