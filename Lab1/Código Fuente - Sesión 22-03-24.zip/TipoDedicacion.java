enum TipoDedicacion{
	TC, TPA, TPC
}