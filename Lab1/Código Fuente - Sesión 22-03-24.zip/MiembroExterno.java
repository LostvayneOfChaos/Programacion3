class MiembroExterno extends Miembro{
	private char dedicacion;
}