import java.util.*;
import java.text.*;

public class Clinica{
	private String nombre;
	private String direccion;
	private TipoCiudad ciudad;
	private ArrayList<Persona> trabajadores;
	
	public Clinica(){
		trabajadores = new ArrayList<Persona>();
	}
	
	public void finalize(){}

	public String getNombre (){
		return nombre;
	}

	public void setNombre (String _nombre){
		this.nombre = _nombre;
	}

	public String getDireccion (){
		return direccion;
	}

	public void setDireccion (String _direccion){
		this.direccion = _direccion;
	}

	public TipoCiudad getCiudad (){
		return ciudad;
	}

	public void setCiudad (TipoCiudad _ciudad){
		this.ciudad = _ciudad;
	}
	
	public void agregarPersona(Persona x){
		if(trabajadores.size() == 0) x.setIdTrabajador(1);
		else x.setIdTrabajador((int)trabajadores.size() + 1);
		trabajadores.add(x);
	}
	
	public String mostrarMedyAdmin(){
		String res = "";
		res += "Clinica: " + nombre + "\n";
		res += "Reporte: Lista de medicos y administrativos\n\n";
		
		for(Persona x : trabajadores){
			if(x instanceof Medico) res += ((Medico)x).consultarDatos() + "\n";
			else if(x instanceof Administrativo) res += ((Administrativo)x).consultarDatos() + "\n";
		}
		return res;
	}
}