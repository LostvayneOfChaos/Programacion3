import java.util.*;
import java.text.*;

public class Especialidad{
	private String nombreEsp;
	private TipoEsp clasificacion;
	
	public Especialidad(){}
	public void finalize(){}

	public String getNombreEsp (){
		return nombreEsp;
	}

	public void setNombreEsp (String _nombreEsp){
		this.nombreEsp = _nombreEsp;
	}

	public TipoEsp getClasificacion (){
		return clasificacion;
	}

	public void setClasificacion (TipoEsp _clasificacion){
		this.clasificacion = _clasificacion;
	}
}