enum TipoEsp { C, Q, L}
enum TipoEstCivil { S, C, D }
enum TipoDedic { TP, TC }
enum TipoRegimen { SNP, FAG, CAS }
enum TipoCiudad { LIM, TRUX, CIX}