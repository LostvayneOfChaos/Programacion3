import java.util.*;
import java.text.*;

public class Medico extends Persona implements IConsultable{
	private String apMaterno;
	private String numColegiatura;
	private Especialidad especialidad;

	public Medico(){
		super();
		especialidad = new Especialidad();
	}
	
	public void finalize(){}
	
	public String getApMaterno (){
		return apMaterno;
	}

	public void setApMaterno (String _apMaterno){
		this.apMaterno = _apMaterno;
	}

	public String getNumColegiatura (){
		return numColegiatura;
	}

	public void setNumColegiatura (String _numColegiatura){
		this.numColegiatura = _numColegiatura;
	}
	
	public void asignarEspecialidad (Especialidad _especialidad){
		this.especialidad.setNombreEsp(_especialidad.getNombreEsp());
		this.especialidad.setClasificacion(_especialidad.getClasificacion());
	}

	public String consultarDatos(){
		return this.nombres + " " + this.apPaterno + " " + this.apMaterno + " - " + this.especialidad.getNombreEsp();
	}
}