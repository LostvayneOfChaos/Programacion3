import java.util.*;
import java.text.*;

public abstract class Persona{
	protected String nombres;
	protected String apPaterno;
	protected char sexo;
	protected String dni;
	protected int edad;
	protected TipoEstCivil estadoCivil;
	
	protected int idTrabajador;
	protected float salario;
	protected TipoDedic tipoDedic;
	protected String anexo;
	
	public Persona(){}
	public void finalize(){}

	public String getNombres (){
		return nombres;
	}

	public void setNombres (String _nombres){
		this.nombres = _nombres;
	}

	public String getApPaterno (){
		return apPaterno;
	}

	public void setApPaterno (String _apPaterno){
		this.apPaterno = _apPaterno;
	}

	public char getSexo (){
		return sexo;
	}

	public void setSexo (char _sexo){
		this.sexo = _sexo;
	}

	public String getDni (){
		return dni;
	}

	public void setDni (String _dni){
		this.dni = _dni;
	}

	public int getEdad (){
		return edad;
	}

	public void setEdad (int _edad){
		this.edad = _edad;
	}

	public TipoEstCivil getEstadoCivil (){
		return estadoCivil;
	}

	public void setEstadoCivil (TipoEstCivil _estadoCivil){
		this.estadoCivil = _estadoCivil;
	}
	
	public int getIdTrabajador(){
		return idTrabajador;
	}
	
	public void setIdTrabajador(int _idTrabajador){
		this.idTrabajador = _idTrabajador;
	}

	public float getSalario (){
		return salario;
	}

	public void setSalario (float _salario){
		this.salario = _salario;
	}

	public TipoDedic getTipoDedic (){
		return tipoDedic;
	}

	public void setTipoDedic (TipoDedic _tipoDedic){
		this.tipoDedic = _tipoDedic;
	}

	public String getAnexo (){
		return anexo;
	}

	public void setAnexo (String _anexo){
		this.anexo = _anexo;
	}

}