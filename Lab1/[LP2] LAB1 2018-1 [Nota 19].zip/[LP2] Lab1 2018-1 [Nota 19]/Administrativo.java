import java.util.*;
import java.text.*;

public class Administrativo extends Persona implements IConsultable{
	private String apMaterno;
	private TipoRegimen regimen;
	private String funcion;
	
	public Administrativo(){
		super();	
	}
	
	public void finalize(){}

	public String getApMaterno (){
		return apMaterno;
	}

	public void setApMaterno (String _apMaterno){
		this.apMaterno = _apMaterno;
	}

	public TipoRegimen getRegimen (){
		return regimen;
	}

	public void setRegimen (TipoRegimen _regimen){
		this.regimen = _regimen;
	}

	public String getFuncion (){
		return funcion;
	}

	public void setFuncion (String _funcion){
		this.funcion = _funcion;
	}
	
	public String consultarDatos(){
		String dedic, regim;
		if(this.tipoDedic == TipoDedic.TP) dedic = "TP";
		else dedic = "TC";
		
		if(this.regimen == TipoRegimen.SNP) regim = "SNP";
		else if(this.regimen == TipoRegimen.FAG) regim = "FAG";
		else regim = "CAS";
		
		return this.nombres + " " + this.apPaterno + " " + this.apMaterno + " - " + dedic + " - " + regim;
	}
}