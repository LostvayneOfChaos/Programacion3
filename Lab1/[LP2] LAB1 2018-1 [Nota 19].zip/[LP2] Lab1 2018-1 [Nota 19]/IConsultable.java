import java.util.*;
import java.text.*;

public interface IConsultable{
	String consultarDatos();
}