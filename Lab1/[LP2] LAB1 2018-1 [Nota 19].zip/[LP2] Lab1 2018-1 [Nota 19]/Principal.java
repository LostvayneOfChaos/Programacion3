import java.util.*;
import java.text.*;

public class Principal{
	public static void main(String[] args){
		Clinica clinica1 = new Clinica();
		clinica1.setNombre("HCM SAN MIGUEL");
		
		Especialidad esp1 = new Especialidad(); esp1.setNombreEsp("DERMATOLOGIA");
		Especialidad esp2 = new Especialidad(); esp2.setNombreEsp("PEDIATRIA");
		
		Persona p1 = new Medico(); p1.setNombres("JUAN"); p1.setApPaterno("PEREZ"); ((Medico)p1).setApMaterno("ORTIZ");
		Persona p2 = new Medico(); p2.setNombres("MARIA"); p2.setApPaterno("ALVARADO"); ((Medico)p2).setApMaterno("MENDOZA");
		((Medico)p1).asignarEspecialidad(esp1);
		((Medico)p2).asignarEspecialidad(esp2);
		
		Persona p3 = new Administrativo(); p3.setNombres("KARLA"); p3.setApPaterno("CORDOVA"); ((Administrativo)p3).setApMaterno("ARELLANO");
		((Administrativo)p3).setRegimen(TipoRegimen.CAS); p3.setTipoDedic(TipoDedic.TP);
		
		Persona p4 = new Ejecutivo(); p4.setNombres("ERASMO"); p4.setApPaterno("MONTOYA");
		
		clinica1.agregarPersona(p1);
		clinica1.agregarPersona(p3);
		clinica1.agregarPersona(p2);
		clinica1.agregarPersona(p4);
		
		String reporte = clinica1.mostrarMedyAdmin();
		System.out.println(reporte);
	}
}