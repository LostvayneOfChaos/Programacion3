import java.util.*;
import java.text.*;

public class Ejecutivo extends Persona{
	private String numPasaporte;
	private String ssn;

	public Ejecutivo(){
		super();
	}
	
	public void finalize(){}
	
	public String getNumPasaporte (){
		return numPasaporte;
	}

	public void setNumPasaporte (String _numPasaporte){
		this.numPasaporte = _numPasaporte;
	}

	public String getSsn (){
		return ssn;
	}

	public void setSsn (String _ssn){
		this.ssn = _ssn;
	}
}