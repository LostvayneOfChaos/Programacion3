import java.util.Date;
class Persona extends Artista{
	private String apellidoP;
	private String nombreP;
	private char genero;
	private Date fechaNacimiento;
	private Agrupacion agrupacion;
	
	
	public Persona(String nombre, OrigenArtista origen,
		String nombreP,String apellidoP, Date fechaNacimiento, char genero){
		this.nombreP=nombreP;
		this.apellidoP=apellidoP;
		setOrigen(origen);
		this.fechaNacimiento = fechaNacimiento;
		this.genero = genero;
		setNombre(nombre);
	}
	
	
	public String consultarDatos(){
		return "PERSONA  " + getNombre() + " - "+ getOrigen()+ "\n";
	} 
	
	
	
	
	
}