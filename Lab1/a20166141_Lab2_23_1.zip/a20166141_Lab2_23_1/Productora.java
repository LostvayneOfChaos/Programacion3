import java.util.ArrayList;
class Productora{
	private String nombre;
	private int id;
	private ArrayList<Evento> eventos;
	
	public Productora( int id, String nombre){
		this.nombre= nombre;
		this.id= id;
	}
	
	public void setEventos(ArrayList<Evento> eventos){
		this.eventos=eventos;
	}
	
	
	public  ArrayList<Evento>  getEventos(){
		return eventos;
	}
	
	public String consultarEventos(){
		String reporte="";
		//Recorremos todos los miembros del equipo con índice "numero".
		for(Evento m : eventos){
			/* El enunciado menciona que la clase EQuipu tiene la obligacion de:
			"consultar los datos de todos los miembros PUCP (alumnos y profesores) de un equipo en particular". Esto excluye a los miembros externos.
			Si se tuviera un miembro externo como parte del equipo, no sería impreso en el reporte.
			Nótese además que se está llamando al método "consultarDatos" de la clase "MiembroPUCP" (clase base), pero debido a la sobreescritura del método, se llama al comportaiento específico establecido en la clase derivada.
			*/
			reporte = reporte + m.consultarDatos();
			
			if(m instanceof Evento)
				
				reporte = reporte + m.consultarDatosArtistasyFuncionesEvento();
		}
		return reporte;
		
	}
	
	
	
	
	
}