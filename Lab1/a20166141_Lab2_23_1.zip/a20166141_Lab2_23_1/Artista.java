
abstract class Artista implements IConsultable{
	private String nombre;
	private OrigenArtista origen;
	private Evento evento;
	
	public String getNombre(){
		return nombre;
	}
	public void  setNombre(String nombre){
		this.nombre=nombre;
	}
	public void  setOrigen(OrigenArtista origen){
		this.origen=origen;
	}
	
	public OrigenArtista getOrigen(){
		return origen;
	}
	
	public abstract String consultarDatos();
	
	
}