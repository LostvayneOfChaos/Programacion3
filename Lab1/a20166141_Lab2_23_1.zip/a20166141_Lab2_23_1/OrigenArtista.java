enum OrigenArtista{
	NACIONAL,INTERNACIONAL
	
}