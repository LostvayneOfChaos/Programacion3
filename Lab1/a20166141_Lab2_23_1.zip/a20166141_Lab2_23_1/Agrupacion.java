import java.util.ArrayList;
class Agrupacion extends Artista{
	private int anioConformacion;
	private ArrayList<Persona> miembros;
	
	public Agrupacion(String nombre, OrigenArtista origen,
		int anioConformacion){
			
		setOrigen(origen);
		this.anioConformacion = anioConformacion;
		setNombre(nombre);
	}
	
	public void setMiembros(ArrayList<Persona> miembros){
		this.miembros=miembros;
	}
	
	public ArrayList<Persona> getMiembros(){
		return miembros;
	}
	
	
	public int getAnioConformacion(){
		return anioConformacion;
	}
	
	
	public String consultarDatos(){
		return "AGRUPACION   " + getNombre() + " - "+ getOrigen()+ " - "+ getAnioConformacion()+ "\n";
	}
	
	
	
}