
class ObraTeatral extends Evento{
	private int cantTotalActosTeatrales;
	private boolean idObraInmersiva;
	
	public ObraTeatral(String nombre,double costoRealizacion, 
		boolean esBenefico, int cantTotalActosTeatrales, boolean idObraInmersiva){
		super(nombre,costoRealizacion,esBenefico);
		//setNombre(nombre);
		//setCostoRealizacion(costoRealizacion);
		//setEsBenefico(esBenefico);
		//aca uso super,porque usaria set si puediese crear evento pero como no puedo porque es abstracto
		this.cantTotalActosTeatrales=cantTotalActosTeatrales;
		this.idObraInmersiva = idObraInmersiva;
	}
	
	
	
	
	@Override
	public String consultarDatos(){
		return "OBRRA TEATRAL : " + getNombre()+ "-Benefica: "+ getEsBenefico()+ "-Inmersiva :"+
		idObraInmersiva+"\n";
		//super.consultarDatosArtistasyFuncionesEvento();
	}
	
	
	
	
	
	
}