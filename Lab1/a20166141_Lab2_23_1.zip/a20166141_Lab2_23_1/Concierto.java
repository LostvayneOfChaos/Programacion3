class Concierto extends Evento{
	private boolean esAcustico;
	private boolean ofreceTecnologiaAsistiva;
	
	public Concierto(String nombre, double costoRealizacion, boolean esBenefico,
				boolean esAcustico,boolean ofreceTecnologiaAsistiva){
		super(nombre, costoRealizacion, esBenefico);
		this.esAcustico = esAcustico;
		this.ofreceTecnologiaAsistiva = ofreceTecnologiaAsistiva;
	}
	
	
	@Override
	public String consultarDatos(){
		return "concierto : " + getNombre()+ "-Acustico: "+ esAcustico + "-TEC ASISTIVA :"+
		ofreceTecnologiaAsistiva +"\n";
		//super.consultarDatosArtistasyFuncionesEvento();
	}
	
	
	
	
}