import java.util.ArrayList;
class Local{
	private String nombre;
	private String direccion;
	private int capacidad;
	private ArrayList<Funcion> funcion;
	
	
	public Local(String nombre, String direccion, int capacidad){
		this.nombre=nombre;
		this.direccion=direccion;
		this.capacidad = capacidad;
	}
	
	
	
	public String getNombre(){
		return nombre;
	}
	
	
	
}