import java.util.ArrayList;

class InstitucionEducativa{
	private int idInstitucionEducativa;
	//todos los atributos son privados siempre
	private String nombre;
	private String RUC;
	private ArrayList<Sede> sedes;
	//la clase es Sede y variable sedes es con minuscula
	
	public InstitucionEducativa(int idInstitucionEducativa, String RUC , String nombre ){
		//Esto es el constructor
		this.idInstitucionEducativa=idInstitucionEducativa;
		this.RUC=RUC;
		this.nombre=nombre;
		
		
	}
	
	public ArrayList<Sede> getSedes(){
		
		return sedes;
		
		
	}
	
	public void setSedes( ArrayList<Sede> sedes){
		this.sedes=sedes;
	}
	
	public String consultarProgramasDeSede(int indiceSede){
		String cadena="Programas disponibles para " + sedes.get(indiceSede).getNombre()+ "\n";
		cadena+=sedes.get(indiceSede).consultarProgramas();
		return cadena;
		
	}
	
	
	
}