interface IConsultable{
	String ConsultarDatos();
}