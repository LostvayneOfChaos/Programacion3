interface IConsultable{
	String consultarDatos();
}