﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalSoft
{
    public class Program
    {
        /* Ingrese sus datos:
         * Codigo PUCP:
         * Nombre Completo:
         * */

        //private static SalaEspecializadaDAO daoSalaEspecializada;
        public static void Main(string[] args)
        {
            int resultado = 0;
            //daoSalaEspecializada = new SalaEspecializadaMySQL();
            do
            {
                System.Console.WriteLine();
                System.Console.WriteLine("SISTEMA DE GESTION DE SALAS ESPECIALIZADAS");
                System.Console.WriteLine("---------------------------------------------------");
                System.Console.WriteLine("1. Registrar nueva sala especializada.");
                System.Console.WriteLine("2. Listar todas las salas especializadas.");
                System.Console.WriteLine("3. Obtener los datos de una sala especializada por id.");
                System.Console.WriteLine("4. Eliminar una sala especializada.");
                System.Console.WriteLine("5. Modificar una sala especializada.");
                System.Console.WriteLine("6. Salir del sistema de gestion.");
                System.Console.Write("Ingrese su opcion: ");
                resultado = Int32.Parse(System.Console.ReadLine());
                if (resultado == 1)
                {
                    //Complete el código
                }
                else if (resultado == 2)
                {

                }
                else if (resultado == 3)
                {
                    //Complete el código
                }
                else if (resultado == 4)
                {
                    //Complete el código
                }
                else if (resultado == 5)
                {
                    //Complete el código
                }
                else
                {
                    System.Console.WriteLine("Ingrese una opcion valida");
                }
            } while (resultado != 6);
        }

        /*
        public static SalaEspecializada solicitarDatosRegistro()
        {
            //Complete el codigo
        }
        */
        /*
        public static SalaEspecializada solicitarDatosModificar(int idSalaEspecializada)
        {
            //Complete el codigo
        }
        */
    }
}
