﻿using MySql.Data.MySqlClient;
using SoftProgDBManager;
using SoftProgGestClientesController.DAO;
using SoftProgGestClientesModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgGestClientesController.MySQL
{
    public class ClienteMySQL : ClienteDAO
    {
        private MySqlConnection con;
        private MySqlCommand comando;
        private MySqlDataReader lector;
        public int insertar(Cliente cliente)
        {
            int resultado = 0;
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "INSERTAR_CLIENTE";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.Add("_id_cliente", MySqlDbType.Int32).Direction
                    = System.Data.ParameterDirection.Output;
                comando.Parameters.AddWithValue("_DNI", cliente.DNI);
                comando.Parameters.AddWithValue("_nombre", cliente.Nombre);
                comando.Parameters.AddWithValue("_apellido_paterno", cliente.ApellidoPaterno);
                comando.Parameters.AddWithValue("_genero", cliente.Genero);
                comando.Parameters.AddWithValue("_fecha_nacimiento", cliente.FechaNacimiento);
                comando.Parameters.AddWithValue("_linea_credito", cliente.LineaCredito);
                comando.Parameters.AddWithValue("_categoria", cliente.Categoria.ToString());
                comando.ExecuteNonQuery();
                cliente.IdPersona = Int32.Parse(
                    comando.Parameters["_id_cliente"].Value.ToString());
                resultado = cliente.IdPersona;
            }
            catch (Exception ex) {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); }catch(Exception ex) { throw new Exception(ex.Message); }
            }
            return resultado;
        }

        public BindingList<Cliente> listarTodos()
        {
            BindingList<Cliente> clientes = new BindingList<Cliente>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_CLIENTES_TODOS";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    Cliente cliente = new Cliente();
                    if (!lector.IsDBNull(lector.GetOrdinal("id_persona")))
                        cliente.IdPersona = lector.GetInt32("id_persona");
                    if(!lector.IsDBNull(lector.GetOrdinal("nombre")))
                        cliente.Nombre = lector.GetString("nombre");
                    if (!lector.IsDBNull(lector.GetOrdinal("apellido_paterno")))
                        cliente.ApellidoPaterno = lector.GetString("apellido_paterno");
                    if (!lector.IsDBNull(lector.GetOrdinal("DNI")))
                        cliente.DNI = lector.GetString("DNI");
                    if (!lector.IsDBNull(lector.GetOrdinal("genero")))
                        cliente.Genero = lector.GetChar("genero");
                    if (!lector.IsDBNull(lector.GetOrdinal("fecha_nacimiento")))
                        cliente.FechaNacimiento = lector.GetDateTime("fecha_nacimiento");
                    if (!lector.IsDBNull(lector.GetOrdinal("linea_credito")))
                        cliente.LineaCredito = lector.GetDouble("linea_credito");
                    if (!lector.IsDBNull(lector.GetOrdinal("categoria")))
                        cliente.Categoria = (Categoria) Enum.Parse(typeof(Categoria),
                            lector.GetString("categoria"));
                    clientes.Add(cliente);
                }
            }catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { lector.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return clientes;
        }
    }
}
