﻿using SoftProgRRHHController.DAO;
using SoftProgRRHHController.MySQL;
using SoftProgRRHHModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class frmGestionAreas : System.Web.UI.Page
    {
        private AreaDAO daoArea;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            Area area = new Area();
            area.Nombre = txtNombre.Text;
            daoArea = new AreaMySQL();
            int resultado = daoArea.insertar(area);
            lblResultado.Text = "Se ha registrado con exito";
        }
    }
}