package pe.edu.pucp.softprog.almacen.model;
public class Producto {
    
}
