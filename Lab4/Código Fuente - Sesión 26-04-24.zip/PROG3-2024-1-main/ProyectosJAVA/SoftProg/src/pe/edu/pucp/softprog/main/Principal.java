package pe.edu.pucp.softprog.main;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import pe.edu.pucp.softprog.gestclientes.dao.ClienteDAO;
import pe.edu.pucp.softprog.gestclientes.model.Categoria;
import pe.edu.pucp.softprog.gestclientes.model.Cliente;
import pe.edu.pucp.softprog.gestclientes.mysql.ClienteMySQL;
import pe.edu.pucp.softprog.rrhh.dao.AreaDAO;
import pe.edu.pucp.softprog.rrhh.dao.EmpleadoDAO;
import pe.edu.pucp.softprog.rrhh.model.Area;
import pe.edu.pucp.softprog.rrhh.model.Empleado;
import pe.edu.pucp.softprog.rrhh.mysql.AreaMySQL;
import pe.edu.pucp.softprog.rrhh.mysql.EmpleadoMySQL;
public class Principal {
    public static void main(String[] args) throws Exception{
        //Creamos un dao de conexión
        AreaDAO daoArea = new AreaMySQL();

        //Creamos un objeto area
        Area area = new Area();
        area.setNombre("SEGURIDAD");
        
        //Lo registramos en la base de datos
        int resultado = daoArea.insertar(area);
        //Mostramos un mensaje de exito o fracaso
        if(resultado!=0)
            System.out.println("El area se ha registrado con exito.");
        else
            System.out.println("Ocurrio un error en el registro.");
        
        //Ahora obtenemos las areas de la base de datos
        ArrayList<Area> areas = daoArea.listarTodas();
        //Las mostramos por pantalla
        for(Area a : areas){
            System.out.println(a.getIdArea() + ". " + a.getNombre());
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        
        Empleado emp = new Empleado("18729345","JUAN","PEREZ",'M',sdf.parse("01-03-1994"),areas.get(0),"GERENTE",3500.00);
        
        EmpleadoDAO daoEmpleado = new EmpleadoMySQL();
        resultado = daoEmpleado.insertar(emp);
        if(resultado != 0){
            System.out.println("El empleado se ha registrado con exito");
        }
        
//        emp.setNombre("MANUEL");
//        resultado = daoEmpleado.modificar(emp);
//        if(resultado!=0){
//            System.out.println("Se ha modificado con exito");
//        }
//        
//        daoEmpleado.eliminar(emp.getIdPersona());
        
        ArrayList<Empleado> empleados = daoEmpleado.listarTodos();
        for(Empleado empleado : empleados){
            System.out.println(empleado.getIdPersona()+ ". " + empleado.getNombre() + " " + empleado.getApellidoPaterno());
        }
        
        Cliente cliente = new Cliente("98720091","JAVIER","GONZALES",'M',sdf.parse("04-08-1992"),1900.00,Categoria.CLASICO);
        System.out.println(cliente.getCategoria());
        ClienteDAO daoCliente = new ClienteMySQL();
        resultado = daoCliente.insertar(cliente);
        if(resultado != 0){
            System.out.println("Se ha insertado el cliente");
        }
        
        ArrayList<Cliente> clientes = daoCliente.listarTodos();
        for(Cliente c : clientes)
            System.out.println(c.getIdPersona() + ". " + c.getNombre());
        
        /*
            Area areaModificar = areas.get(0);
            areaModificar.setNombre("CAFETERIA");
            int resultado = daoArea.modificar(areaModificar);
        
            if(resultado!=0)
                System.out.println("Se modifico con exito..");
        
            daoArea.eliminar(areaModificar.getIdArea());
        */
    }
}