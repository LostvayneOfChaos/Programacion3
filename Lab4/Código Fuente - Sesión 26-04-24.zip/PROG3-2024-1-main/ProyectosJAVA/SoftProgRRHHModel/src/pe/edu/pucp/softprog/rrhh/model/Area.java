package pe.edu.pucp.softprog.rrhh.model;
import java.util.ArrayList;

public class Area {
    private ArrayList<Empleado> empleados;
    private int idArea;
    private String nombre;
    private boolean activo;

    public Area() {
    }

    public Area(String nombre) {
        this.nombre = nombre;
    }
    
    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }
    
    public int getIdArea() {
        return idArea;
    }

    public void setIdArea(int idArea) {
        this.idArea = idArea;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    
}
