package pe.edu.pucp.softprog.rrhh.mysql;

import java.util.ArrayList;
import pe.edu.pucp.softprog.rrhh.dao.EmpleadoDAO;
import pe.edu.pucp.softprog.rrhh.model.Empleado;
import java.sql.Connection;
import java.sql.ResultSet;
import pe.edu.pucp.softprog.config.DBManager;
import java.sql.CallableStatement;
import java.sql.SQLException;
import pe.edu.pucp.softprog.rrhh.model.Area;


public class EmpleadoMySQL implements EmpleadoDAO{

    private Connection con;
    private CallableStatement cs;
    private ResultSet rs;

    @Override
    public int insertar(Empleado empleado){
        int resultado = 0;
        try{
            con = DBManager.getInstance().getConnection();
            cs = con.prepareCall("{call INSERTAR_EMPLEADO (?,?,?,?,?,?,?,?,?)}");
            cs.registerOutParameter("_id_empleado", java.sql.Types.INTEGER);
            cs.setInt("_fid_area", empleado.getArea().getIdArea());
            cs.setString("_nombre", empleado.getNombre());
            cs.setString("_DNI",empleado.getDNI());
            cs.setString("_apellido_paterno", empleado.getApellidoPaterno());
            cs.setString("_genero", String.valueOf(empleado.getGenero()));
            cs.setDate("_fecha_nacimiento", new java.sql.Date(empleado.getFechaNacimiento().getTime()));
            cs.setString("_cargo", empleado.getCargo());
            cs.setDouble("_sueldo", empleado.getSueldo());
            cs.executeUpdate();
            empleado.setIdPersona(cs.getInt("_id_empleado"));
            resultado = empleado.getIdPersona();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            
            try{con.close();}catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        return resultado;
    }
    
    @Override
    public int modificar(Empleado empleado) {
        int resultado = 0;
        try{
            con = DBManager.getInstance().getConnection();
            cs = con.prepareCall("{call MODIFICAR_EMPLEADO(?,?,?,?,?,?,?,?,?)}");
            cs.setInt("_id_empleado", empleado.getIdPersona());
            cs.setInt("_fid_area", empleado.getArea().getIdArea());
            cs.setString("_nombre", empleado.getNombre());
            cs.setString("_DNI",empleado.getDNI());
            cs.setString("_apellido_paterno", empleado.getApellidoPaterno());
            cs.setString("_genero", String.valueOf(empleado.getGenero()));
            cs.setDate("_fecha_nacimiento", new java.sql.Date(empleado.getFechaNacimiento().getTime()));
            cs.setString("_cargo", empleado.getCargo());
            cs.setDouble("_sueldo", empleado.getSueldo());
            resultado = cs.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            try{con.close();}catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        return resultado;
    }

    @Override
    public int eliminar(int idEmpleado) {
        int resultado = 0;
        try{
            con = DBManager.getInstance().getConnection();
            cs = con.prepareCall("{call ELIMINAR_EMPLEADO (?)}");
            cs.setInt("_id_empleado", idEmpleado);
            resultado = cs.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            try{con.close();}catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        return resultado;
    }

    @Override
    public ArrayList<Empleado> listarTodos() {
        ArrayList<Empleado> empleados = new ArrayList<>();
        try{
            con = DBManager.getInstance().getConnection();
            cs = con.prepareCall("{call LISTAR_EMPLEADOS_TODOS()}");
            rs = cs.executeQuery();
            while(rs.next()){
                Empleado empleado = new Empleado();
                empleado.setIdPersona(rs.getInt("id_persona"));
                empleado.setDNI(rs.getString("DNI"));
                empleado.setNombre(rs.getString("nombre_empleado"));
                empleado.setApellidoPaterno(rs.getString("apellido_paterno"));
                empleado.setGenero(rs.getString("genero").charAt(0));
                empleado.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                empleado.setCargo(rs.getString("cargo"));
                empleado.setSueldo(rs.getDouble("sueldo"));
                empleado.setArea(new Area());
                empleado.getArea().setIdArea(rs.getInt("id_area"));
                empleado.getArea().setNombre(rs.getString("nombre_area"));
                empleados.add(empleado);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            try{con.close();}catch(SQLException ex){System.out.println(ex.getMessage());}
        }
        return empleados;
    }
    
}