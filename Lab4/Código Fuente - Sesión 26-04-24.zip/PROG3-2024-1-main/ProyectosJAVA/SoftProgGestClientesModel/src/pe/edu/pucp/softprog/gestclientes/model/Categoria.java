package pe.edu.pucp.softprog.gestclientes.model;
public enum Categoria {
    CLASICO, VIP, PLATINUM
}