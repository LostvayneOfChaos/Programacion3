﻿using MedicalSoftDBManager;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.Configuration;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace MedicalSoftDBManager
{
    public class DBManager
    {
        private static DBManager dbManager;
        private MySqlConnection con;
        private string cadena;
        private string server = "server=db-labs-prog3-prueba.coi00eiveyrw.us-east-1.rds.amazonaws.com;";
        private string user = "user=user06;";
        private string password = "password=laboratorio0620241;";
        private string port = "port=3306;";
        private string database = "database=laboratorio06;";
        public MySqlConnection Connection
        {
            get
            {
                cadena = server + user + password + port + database;
                con = new MySqlConnection(cadena);
                return con;
            }
        }

        public static DBManager Instance
        {
            get
            {
                if(dbManager == null)
                {
                    createInstance();
                }
                return dbManager;
            }
        }

        private static void createInstance()
        {
            if(dbManager == null)
            {
                dbManager = new DBManager();
            }
        }
    }
}
