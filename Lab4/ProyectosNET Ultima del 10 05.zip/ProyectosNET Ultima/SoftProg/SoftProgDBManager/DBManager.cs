﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgDBManager
{
    public class DBManager
    {
        private MySqlConnection con;

        private static DBManager dbManager;
        private string url = "server=db-prog3-softprog.coi00eiveyrw.us-east-1.rds.amazonaws.com;";
        private string usuario = "user=sa;";
        private string password = "password=prog3softprog;";
        private string puerto = "port=3306;";
        private string basedatos = "database=prog3;";

        public MySqlConnection Connection
        {
            get
            {
                string cadena = url + usuario + password + puerto + basedatos;
                con = new MySqlConnection(cadena);
                return con;
            }
        }

        public static DBManager Instance
        {
            get{
                if (dbManager == null)
                {
                    createInstance();
                }
                return dbManager;
            }
        }

        private static void createInstance()
        {
            if (dbManager == null)
            {
                dbManager = new DBManager();
            }
        }

    }
}
