﻿using SoftProgLogisticaModel.Almacen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgLogisticaController.Almacen.DAO
{
    public interface ProductoDAO
    {
        BindingList<Producto> listarPorNombre(string nombre);
    }
}
