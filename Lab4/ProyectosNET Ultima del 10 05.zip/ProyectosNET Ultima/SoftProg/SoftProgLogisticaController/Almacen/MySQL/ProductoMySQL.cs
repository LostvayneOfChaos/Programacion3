﻿using MySql.Data.MySqlClient;
using SoftProgDBManager;
using SoftProgLogisticaController.Almacen.DAO;
using SoftProgLogisticaModel.Almacen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgLogisticaController.Almacen.MySQL
{
    public class ProductoMySQL : ProductoDAO
    {
        private MySqlCommand comando;
        private MySqlConnection con;
        private MySqlDataReader lector;
        public BindingList<Producto> listarPorNombre(string nombre)
        {
            BindingList<Producto> productos = new BindingList<Producto>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_PRODUCTOS_POR_NOMBRE";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("_nombre", nombre);
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    Producto producto = new Producto();
                    producto.IdProducto = lector.GetInt32("id_producto");
                    producto.Nombre = lector.GetString("nombre");
                    producto.UnidadMedida = lector.GetString("unidad_medida");
                    producto.Precio = lector.GetDouble("precio");
                    producto.Activo = true;
                    productos.Add(producto);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { lector.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return productos;
        }
    }
}
