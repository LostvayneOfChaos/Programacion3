﻿using MySql.Data.MySqlClient;
using SoftProgDBManager;
using SoftProgGestClientesModel;
using SoftProgLogisticaController.Ventas.DAO;
using SoftProgLogisticaModel.Almacen;
using SoftProgLogisticaModel.Ventas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgLogisticaController.Ventas.MySQL
{
    public class OrdenVentaMySQL : OrdenVentaDAO
   {
        private MySqlConnection con;
        private MySqlCommand comando;
        private MySqlDataReader lector;
        public int insertar(OrdenVenta ordenVenta)
        {
            int resultado = 0;
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "INSERTAR_ORDEN_VENTA";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.Add("_id_orden_venta", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                comando.Parameters.AddWithValue("_fid_cliente",ordenVenta.Cliente.IdPersona) ;
                comando.Parameters.AddWithValue("_fid_empleado",1);
                comando.Parameters.AddWithValue("_total",ordenVenta.Total);
                comando.ExecuteNonQuery();
                ordenVenta.IdOrdenVenta = Int32.Parse(comando.Parameters["_id_orden_venta"].Value.ToString());
                foreach (LineaOrdenVenta lov in ordenVenta.LineasOrdenVenta)
                {
                    comando = new MySqlCommand();
                    comando.Connection = con;
                    comando.CommandText = "INSERTAR_LINEA_ORDEN_VENTA";
                    comando.CommandType = System.Data.CommandType.StoredProcedure;
                    comando.Parameters.Add("_id_linea_orden_venta", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                    comando.Parameters.AddWithValue("_fid_orden_venta", ordenVenta.IdOrdenVenta);
                    comando.Parameters.AddWithValue("_fid_producto", lov.Producto.IdProducto);
                    comando.Parameters.AddWithValue("_cantidad", lov.Cantidad);
                    comando.Parameters.AddWithValue("_subtotal", lov.Subtotal);
                    comando.ExecuteNonQuery();
                    lov.IdLineaOrdenVenta = Int32.Parse(comando.Parameters["_id_linea_orden_venta"].Value.ToString());
                }
                resultado = ordenVenta.IdOrdenVenta;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return resultado;
        }

        public BindingList<OrdenVenta> listarTodas()
        {
            BindingList<OrdenVenta> ordenesVenta = new BindingList<OrdenVenta>();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "LISTAR_ORDENES_VENTA_TODAS";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    OrdenVenta ordenVenta = new OrdenVenta();
                    ordenVenta.IdOrdenVenta = lector.GetInt32("id_orden_venta");
                    ordenVenta.Total = lector.GetDouble("total");
                    ordenVenta.FechaHora = lector.GetDateTime("fecha_hora");
                    ordenVenta.Cliente = new Cliente();
                    ordenVenta.Cliente.IdPersona = lector.GetInt32("id_cliente");
                    ordenVenta.Cliente.Nombre = lector.GetString("nombre");
                    ordenVenta.Cliente.ApellidoPaterno = lector.GetString("apellido_paterno");
                    ordenesVenta.Add(ordenVenta);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { lector.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return ordenesVenta;
        }

        public OrdenVenta obtenerPorId(int idOrdenVenta)
        {
            OrdenVenta ordenVenta = new OrdenVenta();
            try
            {
                con = DBManager.Instance.Connection;
                con.Open();
                comando = new MySqlCommand();
                comando.Connection = con;
                comando.CommandText = "OBTENER_ORDEN_VENTA_X_ID";
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("_id_orden_venta", idOrdenVenta);
                lector = comando.ExecuteReader();
                if (lector.Read())
                {
                    ordenVenta.IdOrdenVenta = lector.GetInt32("id_orden_venta");
                    ordenVenta.Total = lector.GetDouble("total");
                    ordenVenta.FechaHora = lector.GetDateTime("fecha_hora");
                    ordenVenta.Cliente = new Cliente();
                    ordenVenta.Cliente.IdPersona = lector.GetInt32("id_cliente");
                    ordenVenta.Cliente.DNI = lector.GetString("DNI");
                    ordenVenta.Cliente.Nombre = lector.GetString("nombre");
                    ordenVenta.Cliente.ApellidoPaterno = lector.GetString("apellido_paterno");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                try { lector.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
                try { con.Close(); } catch (Exception ex) { throw new Exception(ex.Message); }
            }
            return ordenVenta;
        }
    }
}
