﻿using SoftProgLogisticaModel.Ventas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgLogisticaController.Ventas.DAO
{
    public interface OrdenVentaDAO
    {
        int insertar(OrdenVenta ordenVenta);
        BindingList<OrdenVenta> listarTodas();
        OrdenVenta obtenerPorId(int idOrdenVenta);
    }
}
