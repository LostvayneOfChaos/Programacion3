﻿using SoftProgLogisticaModel.Almacen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftProgLogisticaModel.Ventas
{
    public class LineaOrdenVenta
    {
        private int idLineaOrdenVenta;
        private Producto producto;
        private int cantidad;
        private double subtotal;
        private bool activo;

        public int IdLineaOrdenVenta { get => idLineaOrdenVenta; set => idLineaOrdenVenta = value; }
        public Producto Producto { get => producto; set => producto = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        public double Subtotal { get => subtotal; set => subtotal = value; }
        public bool Activo { get => activo; set => activo = value; }
        public string NombreProducto { get => producto.Nombre; }
        public string PrecioProducto { get => producto.Precio.ToString("N2"); }
        public string SubtotalN2 { get => subtotal.ToString("N2"); }

    }
}
