﻿function showModalFormCliente() {
    var modalFormCliente = new bootstrap.Modal(document.getElementById('form-modal-cliente'));
    modalFormCliente.toggle();
}

function showModalFormProducto() {
    var modalFormProducto = new bootstrap.Modal(document.getElementById('form-modal-producto'));
    modalFormProducto.toggle();
}