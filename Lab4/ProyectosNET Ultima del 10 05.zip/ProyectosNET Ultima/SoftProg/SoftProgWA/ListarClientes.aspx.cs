﻿using SoftProgGestClientesController.DAO;
using SoftProgGestClientesController.MySQL;
using SoftProgGestClientesModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class ListarClientes : System.Web.UI.Page
    {
        private ClienteDAO daoCliente;
        private BindingList<Cliente> clientes;
        protected void Page_Load(object sender, EventArgs e)
        {
            daoCliente = new ClienteMySQL();
            clientes = daoCliente.listarPorNombre(txtNombre.Text);
            gvClientes.DataSource = clientes;
            gvClientes.DataBind();
        }

        protected void lbBuscar_Click(object sender, EventArgs e)
        {
            clientes = daoCliente.listarPorNombre(txtNombre.Text);
            gvClientes.DataSource = clientes;
            gvClientes.DataBind();
        }

        protected void gvClientes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvClientes.PageIndex = e.NewPageIndex;
            gvClientes.DataBind();
        }
    }
}