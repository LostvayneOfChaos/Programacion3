﻿using SoftProgGestClientesController.DAO;
using SoftProgGestClientesController.MySQL;
using SoftProgGestClientesModel;
using SoftProgLogisticaController.Almacen.DAO;
using SoftProgLogisticaController.Almacen.MySQL;
using SoftProgLogisticaController.Ventas.DAO;
using SoftProgLogisticaController.Ventas.MySQL;
using SoftProgLogisticaModel.Almacen;
using SoftProgLogisticaModel.Ventas;
using SoftProgRRHHModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class GestionarOrdenesVenta : System.Web.UI.Page
    {
        private ClienteDAO daoCliente;
        private ProductoDAO daoProducto;
        private OrdenVentaDAO daoOrdenVenta;
        private LineaOrdenVentaDAO daoLineaOrdenVenta;

        private BindingList<Cliente> clientes;
        private BindingList<Producto> productos;
        private OrdenVenta ordenVenta;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            daoCliente = new ClienteMySQL();
            daoProducto = new ProductoMySQL();
            daoOrdenVenta = new OrdenVentaMySQL();
            daoLineaOrdenVenta = new LineaOrdenVentaMySQL();

            productos = daoProducto.listarPorNombre(txtNombreProductoModal.Text);
            clientes = daoCliente.listarPorNombre(txtNombreClienteModal.Text);
            
            gvClientes.DataSource = clientes;
            gvClientes.DataBind();

            String accion = Request.QueryString["accion"];
            if (accion != null && accion == "ver" && Session["idOrdenVenta"] != null)
            {
                int idOrdenVenta = (int) Session["idOrdenVenta"];
                ordenVenta = daoOrdenVenta.obtenerPorId(idOrdenVenta);
                ordenVenta.LineasOrdenVenta = daoLineaOrdenVenta.listarPorIdOrdenVenta(idOrdenVenta);
                Session["lineasOrdenVenta"] = ordenVenta.LineasOrdenVenta;
                mostrarDatos();
            }
            else
            {
                ordenVenta = new OrdenVenta();
                if (!IsPostBack)
                {
                    Session["idOrdenVenta"] = null;
                    Session["lineasOrdenVenta"] = null;
                    Session["producto"] = null;
                    Session["cliente"] = null;
                }
            }
            if (Session["lineasOrdenVenta"] == null)
                ordenVenta.LineasOrdenVenta = new BindingList<LineaOrdenVenta>();
            else
                ordenVenta.LineasOrdenVenta = (BindingList<LineaOrdenVenta>) Session["lineasOrdenVenta"];

            gvLineasOrdenVenta.DataSource = ordenVenta.LineasOrdenVenta;
            gvLineasOrdenVenta.DataBind();
        }

        public void mostrarDatos()
        {
            txtDNICliente.Text = ordenVenta.Cliente.DNI;
            txtNombreCliente.Text = ordenVenta.Cliente.NombreCompleto;
            txtTotal.Text = ordenVenta.Total.ToString("N2");
            btnBuscarCliente.Enabled = false;
            btnBuscarProducto.Enabled = false;
            btnGuardar.Enabled = false;
            lbAgregarLOV.Enabled = false;
        }

        protected void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            string script = "window.onload = function() { showModalFormCliente() };";
            ClientScript.RegisterStartupScript(GetType(), "", script, true);
        }

        protected void btnBuscarClienteModal_Click(object sender, EventArgs e)
        {
            clientes = daoCliente.listarPorNombre(txtNombreClienteModal.Text);
            gvClientes.DataSource = clientes;
            gvClientes.DataBind();
        }

        protected void btnSeleccionarModal_Click(object sender, EventArgs e)
        {
            int idPersona = Int32.Parse(((LinkButton)sender).CommandArgument);
            Cliente clienteSeleccionado = clientes.SingleOrDefault(x => x.IdPersona == idPersona);
            Session["cliente"] = clienteSeleccionado;
            txtDNICliente.Text = clienteSeleccionado.DNI;
            txtNombreCliente.Text = clienteSeleccionado.NombreCompleto;
            ScriptManager.RegisterStartupScript(this,GetType(),"","__doPostBack('','');",true);
        }

        protected void btnSeleccionarProductoModal_Click(object sender, EventArgs e)
        {
            int idProducto = Int32.Parse(((LinkButton)sender).CommandArgument);
            Producto productoSeleccionado = productos.SingleOrDefault(x => x.IdProducto == idProducto);
            Session["producto"] = productoSeleccionado;
            txtNombreProducto.Text = productoSeleccionado.NombreProducto;
            txtPrecioUnitProducto.Text = productoSeleccionado.Precio.ToString("N2");
            txtIDProducto.Text = productoSeleccionado.IdProducto.ToString();
            ScriptManager.RegisterStartupScript(this, GetType(), "", "__doPostBack('','');", true);
        }

        protected void gvClientes_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvClientes.PageIndex = e.NewPageIndex;
            gvClientes.DataSource = clientes;
            gvClientes.DataBind();
        }

        protected void btnBuscarProducto_Click(object sender, EventArgs e)
        {
            string script = "window.onload = function() { showModalFormProducto() };";
            ClientScript.RegisterStartupScript(GetType(), "", script, true);
        }

        protected void lbBusquedaProductoModal_Click(object sender, EventArgs e)
        {
            productos = daoProducto.listarPorNombre(txtNombreProductoModal.Text);
            gvProductos.DataSource = productos;
            gvProductos.DataBind();
        }

        protected void lbAgregarLOV_Click(object sender, EventArgs e)
        {
            if(Session["producto"] == null)
            {
                Response.Write("No puede añadir sin haber seleccionado un producto...");
                return;
            }
            if (txtCantidadUnidades.Text.Trim().Equals(""))
            {
                Response.Write("Debe ingresar una cantidad de unidades...");
                return;
            }

            LineaOrdenVenta lov = new LineaOrdenVenta();
            lov.Producto = (Producto) Session["producto"];
            lov.Cantidad = Int32.Parse(txtCantidadUnidades.Text);
            lov.Subtotal = lov.Producto.Precio * lov.Cantidad;
            ordenVenta.LineasOrdenVenta.Add(lov);

            Session["lineasOrdenVenta"] = ordenVenta.LineasOrdenVenta;

            gvLineasOrdenVenta.DataSource = ordenVenta.LineasOrdenVenta;
            gvLineasOrdenVenta.DataBind();

            calcularTotal();

            txtIDProducto.Text = "";
            txtNombreProducto.Text = "";
            txtPrecioUnitProducto.Text = "";
            txtCantidadUnidades.Text = "";
        }

        public void calcularTotal()
        {
            ordenVenta.Total = 0;
            foreach (LineaOrdenVenta lov in ordenVenta.LineasOrdenVenta)
                ordenVenta.Total += lov.Subtotal;
            txtTotal.Text = ordenVenta.Total.ToString("N2");
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            //Validacion de que haya seleccionado un cliente
            if(Session["cliente"] == null)
            {
                Response.Write("Debe elegir un cliente...");
                return;
            }

            ordenVenta.LineasOrdenVenta = (BindingList<LineaOrdenVenta>)Session["lineasOrdenVenta"];
            
            //Validacion de que exista por lo menos 1 linea de orden de venta
            if(ordenVenta.LineasOrdenVenta == null || ordenVenta.LineasOrdenVenta.Count == 0)
            {
                Response.Write("Debe agregar un producto...");
                return;
            }
            
            ordenVenta.Cliente = (Cliente) Session["cliente"];
            calcularTotal();
            int resultado = daoOrdenVenta.insertar(ordenVenta);
            Response.Redirect("ListarOrdenesVenta.aspx");
        }

        protected void btnEliminarProducto_Click(object sender, EventArgs e)
        {

        }

        protected void gvProductos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[1].Text = ((double)DataBinder.Eval(e.Row.DataItem, "Precio")).ToString("N2");
            }
        }
    }
}