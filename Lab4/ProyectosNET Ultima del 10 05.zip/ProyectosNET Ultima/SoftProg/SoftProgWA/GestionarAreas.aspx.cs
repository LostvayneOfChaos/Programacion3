﻿using SoftProgRRHHController.DAO;
using SoftProgRRHHController.MySQL;
using SoftProgRRHHModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class GestionarArea : System.Web.UI.Page
    {
        private AreaDAO daoArea;
        private Area area;
        private Estado estado;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            daoArea = new AreaMySQL();
            area = (Area)Session["area"];
            String accion = Request.QueryString["accion"];
            if (accion != null && accion == "modificar")
            {
                estado = Estado.Modificar;
                if (!IsPostBack) cargarDatos();
            }
            else
                estado = Estado.Nuevo;
        }

        public void cargarDatos()
        {
            txtIdArea.Text = area.IdArea.ToString();
            txtNombre.Text = area.Nombre;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            int resultado = 0;
            area = new Area();
            area.Nombre = txtNombre.Text;
            if (estado == Estado.Nuevo)
                resultado = daoArea.insertar(area);
            else
            {
                area.IdArea = Int32.Parse(txtIdArea.Text);
                resultado = daoArea.modificar(area);
            }
            Response.Redirect("ListarAreas.aspx");
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListarAreas.aspx");
        }
    }
}