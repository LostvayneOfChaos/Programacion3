﻿using SoftProgRRHHController.DAO;
using SoftProgRRHHController.MySQL;
using SoftProgRRHHModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class GestionarEmpleados : System.Web.UI.Page
    {
        private AreaDAO daoArea;
        private EmpleadoDAO daoEmpleado;
        private BindingList<Area> areas;
        private Empleado empleado;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Page_Init(object sender, EventArgs e)
        {
            daoArea = new AreaMySQL();
            daoEmpleado = new EmpleadoMySQL();
            areas = daoArea.listarTodas();
            ddlAreas.DataTextField = "Nombre";
            ddlAreas.DataValueField = "IdArea";
            ddlAreas.DataSource = areas;
            ddlAreas.DataBind();
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            empleado = new Empleado();
            empleado.Nombre = txtNombre.Text;
            empleado.DNI = txtDNI.Text;
            empleado.ApellidoPaterno = txtApellidoPaterno.Text;
            empleado.FechaNacimiento =
                DateTime.Parse(dtpFechaNacimiento.Value);
            if (rbMasculino.Checked)
                empleado.Genero = 'M';
            else
                empleado.Genero = 'F';
            empleado.Area = new Area();
            empleado.Area.IdArea = Int32.Parse(ddlAreas.SelectedValue);
            empleado.Sueldo = Double.Parse(txtSueldo.Text);
            empleado.Cargo = txtCargo.Text;
            daoEmpleado.insertar(empleado);
            Response.Redirect("Home.aspx");
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}