﻿using SoftProgGestClientesModel;
using SoftProgLogisticaController.Ventas.DAO;
using SoftProgLogisticaController.Ventas.MySQL;
using SoftProgLogisticaModel.Ventas;
using SoftProgRRHHModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class ListarOrdenesVenta : System.Web.UI.Page
    {
        private OrdenVentaDAO daoOrdenVenta;
        private BindingList<OrdenVenta> ordenesVenta;
        protected void Page_Load(object sender, EventArgs e)
        {
            daoOrdenVenta = new OrdenVentaMySQL();
            ordenesVenta = daoOrdenVenta.listarTodas();
            gvOrdenesVenta.DataSource = ordenesVenta;
            gvOrdenesVenta.DataBind();
        }

        protected void gvOrdenesVenta_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[0].Text = DataBinder.Eval(e.Row.DataItem, "IdOrdenVenta").ToString();
                e.Row.Cells[1].Text = ((Cliente)DataBinder.Eval(e.Row.DataItem, "Cliente")).NombreCompleto;
                e.Row.Cells[2].Text = ((double)DataBinder.Eval(e.Row.DataItem, "Total")).ToString("N2");
                e.Row.Cells[3].Text = ((DateTime)DataBinder.Eval(e.Row.DataItem, "FechaHora")).ToString("dd-MM-yyyy HH:mm");
            }
        }

        protected void lbRegistrarOrdenVenta_Click(object sender, EventArgs e)
        {
            Response.Redirect("GestionarOrdenesVenta.aspx");
        }

        protected void gvOrdenesVenta_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvOrdenesVenta.PageIndex = e.NewPageIndex;
            gvOrdenesVenta.DataBind();
        }

        protected void lbVerOrdenVenta_Click(object sender, EventArgs e)
        {
            int idOrdenVenta = Int32.Parse(((LinkButton)sender).CommandArgument);
            Session["idOrdenVenta"] = idOrdenVenta;
            Response.Redirect("GestionarOrdenesVenta.aspx?accion=ver");
        }
    }
}