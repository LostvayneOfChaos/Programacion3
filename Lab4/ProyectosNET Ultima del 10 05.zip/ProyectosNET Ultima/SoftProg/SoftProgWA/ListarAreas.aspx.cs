﻿using SoftProgRRHHController.DAO;
using SoftProgRRHHController.MySQL;
using SoftProgRRHHModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftProgWA
{
    public partial class ListarAreas : System.Web.UI.Page
    {
        private AreaDAO daoArea;
        private BindingList<Area> areas;
        protected void Page_Load(object sender, EventArgs e)
        {
            daoArea = new AreaMySQL();
            areas = daoArea.listarTodas();
            gvAreas.DataSource = areas;
            gvAreas.DataBind();
        }

        protected void lbRegistrarArea_Click(object sender, EventArgs e)
        {
            Response.Redirect("GestionarAreas.aspx");
        }

        protected void lbEditarArea_Click(object sender, EventArgs e)
        {
            int idArea = Int32.Parse(((LinkButton)sender).CommandArgument);
            Area area = areas.SingleOrDefault(x => x.IdArea == idArea);
            Session["area"] = area;
            Response.Redirect("GestionarAreas.aspx?accion=modificar");
        }

        protected void lbEliminarArea_Click(object sender, EventArgs e)
        {
            int idArea = Int32.Parse(((LinkButton)sender).CommandArgument);
            daoArea.eliminar(idArea);
            Response.Redirect("ListarAreas.aspx");
        }

        protected void gvAreas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvAreas.PageIndex = e.NewPageIndex;
            gvAreas.DataBind();
        }
    }
}